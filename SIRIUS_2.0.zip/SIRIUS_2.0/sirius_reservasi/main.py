"""
SIRIUS Undip — Sistem Reservasi Ruangan
Tugas Design Pattern (OOP + Flet)

Run in a browser:   flet run --web main.py
Run as desktop app: flet run main.py

Design Patterns used (see each module's docstring for the full
problem/solution writeup):
  - Singleton        patterns/singleton.py   (services/repository.py)
  - State            patterns/state.py       (models/reservation.py)
  - Observer         patterns/observer.py    (services/reservation_service.py)
  - Factory Method   patterns/factory.py     (services/notification_service.py)
  - Strategy         patterns/strategy.py    (views/katalog_view.py)
"""
from __future__ import annotations

import flet as ft

from patterns.observer import CallbackObserver
from patterns.strategy import DEFAULT_STRATEGY
from services.auth_service import AuthService
from services.notification_service import NotificationService
from services.repository import Repository
from services.user_service import UserService
from services.reservation_service import ReservationService
from services.seed import seed_demo_data
from views import (katalog_view, login_view, navbar, notifikasi_view, pengajuan_view,
                   pengguna_view, persetujuan_view, riwayat_view, theme as th)

ROUTE_BUILDERS = {
    "login": lambda ctx: login_view.build(ctx.width, ctx.auth, ctx.state, ctx.go),
    "katalog": lambda ctx: katalog_view.build(ctx.width, ctx.repo, ctx.state, ctx.go, ctx.toast),
    "pengajuan": lambda ctx: pengajuan_view.build(
        ctx.width, ctx.page, ctx.repo, ctx.service, ctx.state, ctx.go, ctx.toast, ctx.file_picker,
        ctx.user),
    "riwayat": lambda ctx: riwayat_view.build(ctx.width, ctx.repo, ctx.service, ctx.go, ctx.toast, ctx.user),
    "notifikasi": lambda ctx: notifikasi_view.build(ctx.width, ctx.repo, ctx.go, ctx.toast, ctx.user),
    "persetujuan": lambda ctx: persetujuan_view.build(
        ctx.width, ctx.page, ctx.repo, ctx.service, ctx.state, ctx.go, ctx.toast, ctx.user),
    "pengguna": lambda ctx: pengguna_view.build(
        ctx.width, ctx.page, ctx.repo, ctx.users, ctx.state, ctx.go, ctx.toast, ctx.user),
}


class AppState:
    """UI-side navigation/draft state. Deliberately separate from the
    Repository: this is *view* state (which page is open, what the user has
    half-typed into the form), not domain data."""

    def __init__(self) -> None:
        self.route = "login"
        self.login_form: dict = {}
        self.reset_session()

    def reset_session(self) -> None:
        """Dipanggil saat login/logout agar draft & filter user sebelumnya
        tidak bocor ke user berikutnya di sesi browser yang sama."""
        self.selected_room_id: str | None = None
        self._preselect_pending = False
        self.sort_strategy = DEFAULT_STRATEGY()
        self.form_draft: dict = {"files": []}
        self.approval_filter: str | None = "Pending"
        self.user_form: dict = {"role": "pemohon"}
        self.login_form = {}

    def consume_preselect_room(self) -> bool:
        if self._preselect_pending:
            self._preselect_pending = False
            return True
        return False

    def request_room(self, room_id: str) -> None:
        self.selected_room_id = room_id
        self._preselect_pending = True


class Context:
    """Small bag of everything a view-builder needs, so each `build(...)`
    signature doesn't have to keep growing."""

    def __init__(self, page: ft.Page, repo, service, auth, users, state: AppState, file_picker, go, toast):
        self.page = page
        self.repo = repo
        self.service = service
        self.auth = auth
        self.users = users
        self.state = state
        self.file_picker = file_picker
        self.go = go
        self.toast = toast

    @property
    def user(self):
        return self.auth.current_user

    @property
    def width(self) -> float:
        return self.page.width or 1440


def main(page: ft.Page):
    page.title = "SIRIUS Undip - Sistem Reservasi Ruangan"
    page.padding = 0
    page.spacing = 0
    page.bgcolor = th.PAGE_BG
    page.scroll = ft.ScrollMode.AUTO
    page.horizontal_alignment = ft.CrossAxisAlignment.STRETCH
    page.theme_mode = ft.ThemeMode.LIGHT
    page.fonts = th.FONT_MAP

    # ---- wire the architecture ---------------------------------------------
    repo = Repository()  # Singleton: same instance everywhere it's constructed
    service = ReservationService(repo)
    notification_service = NotificationService(repo)
    service.subscribe(notification_service)  # Observer: domain-side reaction

    auth = AuthService(repo)  # per sesi browser: siapa yang sedang login
    users = UserService(repo)
    state = AppState()
    file_picker = ft.FilePicker()
    page.services.append(file_picker)

    def toast(message: str):
        page.show_dialog(ft.SnackBar(th.txt(message, 14, th.POPPINS, th.WHITE)))

    def resolve_route() -> str:
        """Penjaga akses: belum login -> Login; sudah login tetapi halaman
        bukan hak role-nya -> halaman awal role tersebut."""
        user = auth.current_user
        if user is None:
            return "login"
        if state.route == "login" or not auth.can_access(state.route):
            return user.role.home_route
        return state.route

    def logout():
        auth.logout()
        state.reset_session()
        state.route = "login"
        render()

    def render(*_args):
        state.route = resolve_route()
        ctx = Context(page, repo, service, auth, users, state, file_picker, go, toast)
        body = ROUTE_BUILDERS[state.route](ctx)
        page.controls = [
            navbar.build_navbar(ctx.width, state.route, go, ctx.user, logout),
            body,
        ]
        page.update()

    def go(route: str, room_id: str | None = None):
        if room_id:
            state.request_room(room_id)
        state.route = route
        render()

    if not repo.reservations:  # only seed once, even if main() re-runs
        seed_demo_data(service, repo)

    # Observer: re-render whenever a reservation changes anywhere in the app,
    # instead of every call site remembering to call page.update() itself.
    service.subscribe(CallbackObserver(render))

    page.on_resize = render
    render()


if __name__ == "__main__":
    ft.run(main, assets_dir="assets")
