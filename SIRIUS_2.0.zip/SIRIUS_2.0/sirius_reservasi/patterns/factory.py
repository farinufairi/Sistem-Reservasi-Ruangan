"""
Factory Method (Creational)

Problem: turning a reservation event ("approved", "rejected", ...) into a
user-facing Notification means picking the right icon, color, title and
message text for that event. If every caller built that `Notification(...)`
object by hand, the formatting rules would be duplicated (and would drift)
wherever a notification is created.

Solution: `NotificationFactory.create()` is the single place that knows how
to turn an event + a reservation into a `Notification`. `NotificationService`
(the Observer that reacts to reservation events) calls the factory instead
of constructing the object itself. Adding a new event type, e.g. "reminder",
only means adding one entry to `_TEMPLATES`.
"""
from __future__ import annotations

from typing import TYPE_CHECKING

from models.notification import Notification

if TYPE_CHECKING:
    from models.reservation import Reservation

ADMIN_AUDIENCE = "role:admin"   # penerima untuk semua admin

# event -> daftar (audience, template). audience "requester" = pemohon yang
# mengajukan, "admin" = semua admin.
_TEMPLATES = {
    "submitted": [
        ("requester", dict(
            icon="hourglass_empty", color="#B54708", title="Pengajuan Terkirim",
            message=lambda r: f"Pengajuan {r.room.name} sedang menunggu persetujuan.")),
        ("admin", dict(
            icon="inbox", color="#030095", title="Pengajuan Baru Masuk",
            message=lambda r: f"{r.requester} mengajukan {r.room.name} pada {r.date:%d %b %Y}.")),
    ],
    "approved": [
        ("requester", dict(
            icon="check_circle", color="#027A48", title="Pengajuan Disetujui",
            message=lambda r: f"Reservasi {r.room.name} pada {r.date:%d %b %Y} telah disetujui.")),
    ],
    "rejected": [
        ("requester", dict(
            icon="cancel", color="#B42318", title="Pengajuan Ditolak",
            message=lambda r: f"Reservasi {r.room.name} pada {r.date:%d %b %Y} ditolak.")),
    ],
    "cancelled": [
        ("requester", dict(
            icon="event_busy", color="#667085", title="Reservasi Dibatalkan",
            message=lambda r: f"Reservasi {r.room.name} pada {r.date:%d %b %Y} telah dibatalkan.")),
        ("admin", dict(
            icon="event_busy", color="#667085", title="Pemohon Membatalkan Reservasi",
            message=lambda r: f"{r.requester} membatalkan {r.room.name} pada {r.date:%d %b %Y}.")),
    ],
}


class NotificationFactory:
    @staticmethod
    def create_all(event: str, reservation: "Reservation") -> list[Notification]:
        """Satu event bisa menghasilkan beberapa notifikasi (pemohon + admin)."""
        templates = _TEMPLATES.get(event)
        if templates is None:
            raise ValueError(f"Tidak ada template notifikasi untuk event '{event}'.")
        result = []
        for audience, tpl in templates:
            recipient = reservation.requester if audience == "requester" else ADMIN_AUDIENCE
            result.append(Notification(
                id=f"N-{reservation.id}-{event}-{audience}",
                icon=tpl["icon"], color=tpl["color"], title=tpl["title"],
                message=tpl["message"](reservation),
                reservation_id=reservation.id, recipient=recipient,
            ))
        return result
