"""
Singleton (Creational)

Problem: every view (Katalog, Pengajuan, Riwayat, Notifikasi) needs to read
and write the SAME list of rooms / reservations / notifications. If each
service created its own in-memory store, the views would drift out of sync
(e.g. a reservation submitted in Pengajuan would never show up in Riwayat).

Solution: `SingletonMeta` forces every class that uses it as a metaclass to
have exactly one instance per process. `Repository` (services/repository.py)
uses it, so `Repository()` called from any module always returns the same
object.
"""
from __future__ import annotations

import threading
from typing import Any


class SingletonMeta(type):
    """Thread-safe singleton metaclass."""

    _instances: dict[type, Any] = {}
    _lock = threading.Lock()

    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            with cls._lock:
                if cls not in cls._instances:  # double-checked locking
                    cls._instances[cls] = super().__call__(*args, **kwargs)
        return cls._instances[cls]
