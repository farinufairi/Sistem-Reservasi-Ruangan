"""
Strategy (Behavioral)

Problem: the Katalog page lets the user re-order the room list (by name, by
capacity, or to show available rooms first). Implementing this as
`if sort_mode == "name": ... elif sort_mode == "capacity": ...` inside the
view mixes UI code with ordering rules, and every new sort option means
editing that same growing if/elif chain.

Solution: each ordering rule is a small `RoomSortStrategy` object with one
method, `apply(rooms)`. `KatalogView` just holds "the current strategy" and
calls `strategy.apply(rooms)` — it never needs to know *how* a given
ordering works. Swapping the strategy (e.g. when the user taps a filter
chip) is a one-line assignment, and a new ordering is a new class, not a
new branch.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from models.room import Room


class RoomSortStrategy(ABC):
    label: str

    @abstractmethod
    def apply(self, rooms: list["Room"]) -> list["Room"]: ...


class SortByName(RoomSortStrategy):
    label = "Nama (A-Z)"

    def apply(self, rooms: list["Room"]) -> list["Room"]:
        return sorted(rooms, key=lambda r: r.name)


class SortByCapacityDesc(RoomSortStrategy):
    label = "Kapasitas Terbesar"

    def apply(self, rooms: list["Room"]) -> list["Room"]:
        return sorted(rooms, key=lambda r: r.capacity, reverse=True)


class SortByAvailableFirst(RoomSortStrategy):
    label = "Tersedia Dahulu"

    def apply(self, rooms: list["Room"]) -> list["Room"]:
        return sorted(rooms, key=lambda r: not r.available)


DEFAULT_STRATEGY = SortByAvailableFirst
ALL_STRATEGIES: list[type[RoomSortStrategy]] = [
    SortByAvailableFirst,
    SortByName,
    SortByCapacityDesc,
]
