"""
Observer (Behavioral)

Problem: when a reservation is submitted, approved, rejected, or cancelled,
several unrelated things need to react: a notification has to appear in the
Notifikasi page, the Riwayat list needs to re-render, and the summary counts
on screen need to update. If `ReservationService` called each of these
directly, it would need to import the notification UI, the history view,
and the dashboard — three layers reaching back into each other.

Solution: `ReservationService` only knows about the generic
`ReservationObserver` interface. Anyone who cares subscribes to it. Right
now two things subscribe: `NotificationService` (turns the event into a
Notification, see patterns/factory.py) and a tiny `CallbackObserver` that
`main.py` uses to re-render the page. Adding a future observer (e.g. an
email reminder service) means writing one new class, not editing
`ReservationService`.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Callable, TYPE_CHECKING

if TYPE_CHECKING:
    from models.reservation import Reservation

# Events a Reservation can broadcast.
EVENT_SUBMITTED = "submitted"
EVENT_APPROVED = "approved"
EVENT_REJECTED = "rejected"
EVENT_CANCELLED = "cancelled"


class ReservationObserver(ABC):
    @abstractmethod
    def update(self, reservation: "Reservation", event: str) -> None: ...


class ReservationSubject:
    """Mixin providing subscribe/unsubscribe/notify. Subclassed by
    ReservationService."""

    def __init__(self) -> None:
        self._observers: list[ReservationObserver] = []

    def subscribe(self, observer: ReservationObserver) -> None:
        if observer not in self._observers:
            self._observers.append(observer)

    def unsubscribe(self, observer: ReservationObserver) -> None:
        if observer in self._observers:
            self._observers.remove(observer)

    def notify(self, reservation: "Reservation", event: str) -> None:
        for observer in list(self._observers):
            observer.update(reservation, event)


class CallbackObserver(ReservationObserver):
    """Adapts a plain function (e.g. a Flet page.update) to the Observer
    interface, so the UI layer can react without becoming a "real" domain
    observer itself."""

    def __init__(self, callback: Callable[["Reservation", str], None]) -> None:
        self._callback = callback

    def update(self, reservation: "Reservation", event: str) -> None:
        self._callback(reservation, event)
