"""
Strategy (Behavioral) — kebijakan akses per Role

Problem: aplikasi sekarang punya dua sisi (Pemohon dan Admin) dengan menu,
halaman awal, dan hak akses yang berbeda. Jika dikerjakan dengan
`if user.role == "admin": ... elif user.role == "pemohon": ...` di navbar, di
router, dan di service, aturan akses akan tersebar dan mudah tidak sinkron
(menu tampil tapi aksinya ditolak, atau sebaliknya).

Solution: setiap role adalah class kecil (`Role`) yang membawa kebijakan
aksesnya sendiri: kumpulan permission, menu navigasi, dan halaman awal.
View dan service hanya bertanya `user.can(Permission.X)` atau
`role.nav_links` — tidak pernah membandingkan nama role. Menambah role baru
(mis. "Petugas Gedung") cukup dengan menulis satu class baru.
"""
from __future__ import annotations

from abc import ABC


class Permission:
    """Daftar hak akses (konstanta string, bukan Enum, agar mudah dibaca)."""

    VIEW_CATALOG = "view_catalog"
    SUBMIT_RESERVATION = "submit_reservation"
    VIEW_OWN_HISTORY = "view_own_history"
    CANCEL_OWN_RESERVATION = "cancel_own_reservation"
    VIEW_NOTIFICATIONS = "view_notifications"
    APPROVE_RESERVATION = "approve_reservation"
    MANAGE_USERS = "manage_users"


# Satu halaman = satu permission. Dipakai router untuk memblokir akses langsung
# ke halaman yang bukan hak role tersebut.
ROUTE_PERMISSION = {
    "katalog": Permission.VIEW_CATALOG,
    "pengajuan": Permission.SUBMIT_RESERVATION,
    "riwayat": Permission.VIEW_OWN_HISTORY,
    "notifikasi": Permission.VIEW_NOTIFICATIONS,
    "persetujuan": Permission.APPROVE_RESERVATION,
    "pengguna": Permission.MANAGE_USERS,
}


class Role(ABC):
    key: str = ""
    label: str = ""
    home_route: str = ""
    permissions: frozenset[str] = frozenset()
    nav_links: list[tuple[str, str]] = []

    def can(self, permission: str) -> bool:
        return permission in self.permissions

    def can_access(self, route: str) -> bool:
        needed = ROUTE_PERMISSION.get(route)
        return needed is not None and self.can(needed)

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__}>"


class PemohonRole(Role):
    key = "pemohon"
    label = "Pemohon"
    home_route = "katalog"
    permissions = frozenset({
        Permission.VIEW_CATALOG,
        Permission.SUBMIT_RESERVATION,
        Permission.VIEW_OWN_HISTORY,
        Permission.CANCEL_OWN_RESERVATION,
        Permission.VIEW_NOTIFICATIONS,
    })
    nav_links = [("Katalog", "katalog"), ("Pengajuan", "pengajuan"),
                 ("Riwayat", "riwayat"), ("Notifikasi", "notifikasi")]


class AdminRole(Role):
    key = "admin"
    label = "Admin"
    home_route = "persetujuan"
    permissions = frozenset({
        Permission.APPROVE_RESERVATION,
        Permission.MANAGE_USERS,
        Permission.VIEW_NOTIFICATIONS,
    })
    nav_links = [("Persetujuan", "persetujuan"), ("Kelola Pengguna", "pengguna"),
                 ("Notifikasi", "notifikasi")]


# Daftar role yang boleh dipilih saat membuat akun (key -> class).
ROLES: dict[str, type[Role]] = {PemohonRole.key: PemohonRole, AdminRole.key: AdminRole}
