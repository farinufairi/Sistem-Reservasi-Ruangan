"""
State (Behavioral)

Problem: a Reservation behaves differently depending on its status.
A Pending reservation can be approved, rejected, or cancelled by the
requester. An Approved one can still be cancelled. A Rejected or Cancelled
one is final — nothing should be allowed to change it again. Writing this
as `if status == "pending": ... elif status == "approved": ...` scattered
across the UI and the service layer is exactly the kind of branching logic
that grows unmanageable as more statuses/actions are added.

Solution: each status is its own class implementing the same interface
(`ReservationState`). `Reservation` (models/reservation.py) holds a
reference to its current state object and simply delegates to it. Adding a
new status, or changing which transitions are legal, means touching one
class instead of hunting through every view and service for string
comparisons.
"""
from __future__ import annotations

from abc import ABC, abstractmethod


class InvalidTransition(Exception):
    """Raised when an action is attempted that the current state forbids."""


class ReservationState(ABC):
    label: str = "Unknown"
    color: str = "#667085"
    icon: str = "help"
    # True bila reservasi di state ini benar-benar memakai ruangan (mengunci
    # slot). Hanya Approved yang True: Pending belum dijamin, Rejected dan
    # Dibatalkan membebaskan slot.
    holds_slot: bool = False

    @abstractmethod
    def can_cancel(self) -> bool: ...

    def approve(self) -> "ReservationState":
        raise InvalidTransition(f"Reservasi berstatus '{self.label}' tidak bisa disetujui.")

    def reject(self) -> "ReservationState":
        raise InvalidTransition(f"Reservasi berstatus '{self.label}' tidak bisa ditolak.")

    def cancel(self) -> "ReservationState":
        raise InvalidTransition(f"Reservasi berstatus '{self.label}' tidak bisa dibatalkan.")

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__}>"


class PendingState(ReservationState):
    label = "Pending"
    color = "#B54708"  # amber
    icon = "hourglass_empty"

    def can_cancel(self) -> bool:
        return True

    def approve(self) -> ReservationState:
        return ApprovedState()

    def reject(self) -> ReservationState:
        return RejectedState()

    def cancel(self) -> ReservationState:
        return CancelledState()


class ApprovedState(ReservationState):
    label = "Approved"
    color = "#027A48"  # green
    icon = "check_circle"
    holds_slot = True

    def can_cancel(self) -> bool:
        return True

    def cancel(self) -> ReservationState:
        return CancelledState()


class RejectedState(ReservationState):
    label = "Rejected"
    color = "#B42318"  # red
    icon = "cancel"

    def can_cancel(self) -> bool:
        return False


class CancelledState(ReservationState):
    label = "Dibatalkan"
    color = "#667085"  # gray
    icon = "event_busy"

    def can_cancel(self) -> bool:
        return False
