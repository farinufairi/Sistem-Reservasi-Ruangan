from __future__ import annotations

import flet as ft

from views import theme as th


def build_navbar(width: float, active_route: str, go, user, on_logout):
    """`user` None = belum login (halaman Login): hanya logo + judul, tanpa menu.
    Menu yang tampil berasal dari `user.role.nav_links`, bukan dari if/else role."""
    compact = width < 960
    pad_l = 95 if width >= 1200 else 24
    pad_r = 70 if width >= 1200 else 24
    title_size = 40 if width >= 600 else 28
    nav_links = user.role.nav_links if user else []

    logo = ft.Container(
        width=49,
        height=60,
        content=ft.Image(
            src=th.LOGO_IMG,
            fit=ft.BoxFit.COVER,
            error_content=ft.Icon(ft.Icons.SCHOOL, color=th.WHITE, size=36),
        ),
    )
    title = ft.Container(
        width=258 if width >= 600 else None,
        content=ft.Text(
            "SIRIUS Undip",
            size=title_size,
            color=th.WHITE,
            font_family=th.LOGO_FONT,
            font_family_fallback=["Georgia", "Times New Roman", "serif"],
            no_wrap=True,
        ),
    )

    def link(label, route):
        active = route == active_route
        return ft.Container(
            on_click=lambda e, r=route: go(r),
            content=th.txt(
                label, 17, th.JAKARTA_BOLD, th.WHITE if not active else "#FFD166"
            ),
        )

    left = [logo, ft.Container(width=18 if width >= 600 else 10), title]
    middle: list = [ft.Container(expand=True)]
    right: list = []

    if user is not None:
        logout = ft.Container(
            height=46, padding=ft.Padding.symmetric(horizontal=20),
            bgcolor=th.WHITE, border=ft.Border.all(1, th.CARD_BORDER), border_radius=10,
            alignment=ft.Alignment.CENTER, ink=True, on_click=lambda e: on_logout(),
            content=ft.Row(tight=True, spacing=8, controls=[
                ft.Icon(ft.Icons.LOGOUT, size=18, color=th.LOGIN_TEXT),
                th.txt("Keluar", 16, th.JAKARTA_BOLD, th.LOGIN_TEXT),
            ]),
        )
        chip = ft.Container(
            padding=ft.Padding.only(left=6, right=14, top=6, bottom=6), border_radius=28,
            bgcolor="#26FFFFFF", border=ft.Border.all(1, "#40FFFFFF"),
            content=ft.Row(tight=True, spacing=10, controls=[
                ft.Container(width=34, height=34, border_radius=17, bgcolor="#FFD166",
                             alignment=ft.Alignment.CENTER,
                             content=th.txt(user.initial, 15, th.JAKARTA_BOLD, th.LOGIN_TEXT)),
                ft.Column(tight=True, spacing=0, controls=[
                    th.txt(user.full_name, 14, th.JAKARTA_BOLD, th.WHITE),
                    th.txt(user.role.label, 11, th.JAKARTA_MED, "#E0E0FF"),
                ]),
            ]),
        )
        if compact:
            right = [
                ft.PopupMenuButton(
                    icon=ft.Icons.MENU,
                    icon_color=th.WHITE,
                    items=[
                        ft.PopupMenuItem(content=th.txt(f"{user.full_name} • {user.role.label}", 13,
                                                         th.JAKARTA_MED, th.GRAY_500), disabled=True),
                        *[ft.PopupMenuItem(content=th.txt(label, 15, th.JAKARTA_BOLD),
                                           on_click=lambda e, r=route: go(r))
                          for label, route in nav_links],
                        ft.PopupMenuItem(content=th.txt("Keluar", 15, th.JAKARTA_BOLD),
                                         on_click=lambda e: on_logout()),
                    ],
                )
            ]
        else:
            links = ft.Row(spacing=23, controls=[link(label, route) for label, route in nav_links])
            middle = [links, ft.Container(expand=True)]
            right = [chip, ft.Container(width=14), logout]

    return ft.Container(
        height=102,
        bgcolor=th.NAV_FALLBACK,
        clip_behavior=ft.ClipBehavior.HARD_EDGE,
        content=ft.Stack(
            clip_behavior=ft.ClipBehavior.HARD_EDGE,
            controls=[
                ft.Image(src=th.NAVBAR_IMG, fit=ft.BoxFit.COVER, left=0, right=0, top=-34, height=687),
                ft.Container(
                    left=0,
                    right=0,
                    top=0,
                    bottom=0,
                    padding=ft.Padding.only(left=pad_l, right=pad_r),
                    content=ft.Row(vertical_alignment=ft.CrossAxisAlignment.CENTER,
                                    controls=left + middle + right),
                ),
            ],
        ),
    )
