from __future__ import annotations

import flet as ft

from services.reservation_service import ValidationError
from views import theme as th


def build(width: float, repo, service, go, toast, user):
    margin = 68 if width >= 800 else 16
    content_w = width - 2 * margin
    reservations = repo.reservations_visible_to(user)

    def cancel(reservation):
        def handler(e=None):
            try:
                service.cancel(reservation, user)
            except ValidationError as exc:
                toast(str(exc))
                return
            toast(f"Reservasi {reservation.id} dibatalkan.")
            go("riwayat")
        return handler

    if not reservations:
        cards = [ft.Container(
            bgcolor=th.WHITE, border=ft.Border.all(1, th.CARD_BORDER), border_radius=16,
            padding=32, alignment=ft.Alignment.CENTER,
            content=th.txt("Belum ada riwayat reservasi.", 14, th.POPPINS, th.GRAY_500),
        )]
    else:
        cards = [_history_card(r, content_w, cancel(r)) for r in reservations]

    body = ft.Container(
        width=content_w, margin=ft.Margin.only(left=margin, right=margin),
        content=ft.Column(spacing=20, controls=cards),
    )

    return ft.Container(
        padding=ft.Padding.only(top=48, bottom=80),
        content=ft.Column(spacing=32, controls=[
            ft.Row([th.hero("Riwayat Reservasi Saya",
                             "Pantau jadwal, durasi, tujuan, dan status reservasi ruangan",
                             width, margin)]),
            ft.Row([body], alignment=ft.MainAxisAlignment.CENTER),
        ]),
    )


def _history_card(reservation, content_w, on_cancel):
    wide = content_w >= 900
    details = ft.Row(
        wrap=True, spacing=24, run_spacing=16,
        controls=[
            ft.Column(spacing=4, controls=[
                th.txt("Jadwal", 12, th.POPPINS, th.GRAY_500),
                th.txt(reservation.schedule_text(), 14, th.POPPINS_SEMI, th.TEXT_PRIMARY),
            ]),
            ft.Column(spacing=4, controls=[
                th.txt("Durasi", 12, th.POPPINS, th.GRAY_500),
                th.txt(f"{reservation.duration_hours} Jam", 14, th.POPPINS_SEMI, th.TEXT_PRIMARY),
            ]),
            ft.Column(spacing=4, controls=[
                th.txt("Tujuan", 12, th.POPPINS, th.GRAY_500),
                th.txt(reservation.purpose, 14, th.POPPINS_SEMI, th.TEXT_PRIMARY),
            ]),
        ],
    )

    header = ft.Row(controls=[
        th.badge(reservation.status_label, reservation.status_color),
        ft.Container(width=12),
        th.txt(f"ID reservasi • {reservation.id}", 13, th.POPPINS, th.GRAY_500),
    ])

    left = ft.Column(
        spacing=16, expand=True,
        controls=[header, th.txt(reservation.room.name, 22, th.POPPINS_BOLD, th.TEXT_PRIMARY), details],
    )

    action = (
        th.secondary_button("Ajukan Pembatalan", on_cancel, height=48)
        if reservation.can_cancel()
        else ft.Container(
            padding=ft.Padding.symmetric(horizontal=16, vertical=12),
            content=th.txt("Tidak ada aksi tersedia", 13, th.POPPINS, th.GRAY_500),
        )
    )

    inner = (
        ft.Row(alignment=ft.MainAxisAlignment.SPACE_BETWEEN, vertical_alignment=ft.CrossAxisAlignment.CENTER,
               controls=[left, action])
        if wide
        else ft.Column(spacing=16, controls=[left, action])
    )

    return ft.Container(
        bgcolor=th.WHITE, border=ft.Border.all(1, th.CARD_BORDER), border_radius=16,
        padding=28, shadow=th.SHADOW_CARD, content=inner,
    )
