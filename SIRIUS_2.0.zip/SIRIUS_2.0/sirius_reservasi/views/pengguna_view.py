from __future__ import annotations

import flet as ft

from patterns.role import ROLES
from services.reservation_service import ValidationError
from views import theme as th

SUCCESS = "#027A48"
ROLE_COLOR = {"pemohon": th.PRIMARY, "admin": "#5B21B6"}


def build(width: float, page: ft.Page, repo, users, app_state, go, toast, user):
    margin = 68 if width >= 800 else 16
    content_w = width - 2 * margin
    card_pad = 32 if width >= 600 else 20
    inner = content_w - 2 * card_pad - 2
    fw = (inner - 16) / 2 if inner >= 640 else inner
    form = app_state.user_form       # isi form bertahan walau halaman di-render ulang

    all_users = sorted(repo.users, key=lambda u: (u.role.key != "admin", u.full_name.lower()))
    count_role = lambda key: sum(1 for u in all_users if u.role.key == key)  # noqa: E731

    summary = ft.Row(wrap=True, spacing=16, run_spacing=16, controls=[
        th.summary_card(ft.Icons.GROUP, th.PRIMARY, len(all_users), "Total Pengguna",
                        "Semua akun", content_w, per_row=4),
        th.summary_card(ft.Icons.PERSON, "#027A48", count_role("pemohon"), "Pemohon",
                        "Mengajukan ruangan", content_w, per_row=4),
        th.summary_card(ft.Icons.ADMIN_PANEL_SETTINGS, "#5B21B6", count_role("admin"), "Admin",
                        "Menyetujui pengajuan", content_w, per_row=4),
        th.summary_card(ft.Icons.BLOCK, "#667085", sum(1 for u in all_users if not u.active),
                        "Nonaktif", "Tidak bisa login", content_w, per_row=4),
    ])

    # -- form tambah pengguna ------------------------------------------------
    def set_field(key):
        def handler(e):
            form[key] = e.control.value
        return handler

    def choose_role(key):
        def handler(e=None):
            form["role"] = key
            go("pengguna")
        return handler

    def add_user(e=None):
        try:
            created = users.create_user(user, form.get("username", ""), form.get("full_name", ""),
                                        form.get("role", "pemohon"), form.get("password", ""))
        except ValidationError as exc:
            form["error"] = str(exc)
            form["password"] = ""          # jangan menyimpan password yang ditolak
            go("pengguna")
            return
        app_state.user_form = {"role": "pemohon"}
        toast(f"Pengguna {created.username} ({created.role.label}) berhasil ditambahkan.")
        go("pengguna")

    role_chips = ft.Row(spacing=8, controls=[
        ft.Container(
            padding=ft.Padding.symmetric(horizontal=16, vertical=10), border_radius=20,
            bgcolor=th.PRIMARY if key == form.get("role", "pemohon") else th.WHITE,
            border=ft.Border.all(1, th.PRIMARY if key == form.get("role", "pemohon") else th.CARD_BORDER),
            ink=True, on_click=choose_role(key),
            content=th.txt(cls.label, 13, th.POPPINS_SEMI,
                           th.WHITE if key == form.get("role", "pemohon") else th.PRIMARY),
        )
        for key, cls in ROLES.items()
    ])

    error = form.get("error")
    add_card = ft.Container(
        width=content_w, bgcolor=th.WHITE, border=ft.Border.all(1, th.CARD_BORDER), border_radius=16,
        padding=card_pad, shadow=th.SHADOW_CARD,
        content=ft.Column(spacing=20, controls=[
            ft.Column(spacing=6, controls=[
                th.txt("Tambah Pengguna", 20 if width >= 600 else 18, th.POPPINS_BOLD,
                       th.TEXT_PRIMARY, height=28 / 20),
                th.txt("Buat akun baru lalu sampaikan username dan password-nya ke pengguna.",
                       14, th.POPPINS, th.GRAY_500, height=22 / 14),
            ]),
            *([th.notice(error, "danger")] if error else []),
            ft.Row(spacing=16, run_spacing=16, wrap=True, controls=[
                th.input_field("Username", value=form.get("username", ""), hint="mis. budi.santoso",
                               on_change=set_field("username"), width=fw, icon=ft.Icons.PERSON_OUTLINE),
                th.input_field("Nama Lengkap", value=form.get("full_name", ""), hint="mis. Budi Santoso",
                               on_change=set_field("full_name"), width=fw, icon=ft.Icons.BADGE_OUTLINED),
                ft.Column(width=fw, spacing=4, controls=[
                    th.txt("Role", 12, th.POPPINS, th.GRAY_600, height=16 / 12, spacing=-0.2),
                    ft.Container(height=44, alignment=ft.Alignment.CENTER_LEFT, content=role_chips),
                ]),
                th.input_field("Password", value=form.get("password", ""), hint="Min. 8 karakter, huruf & angka",
                               on_change=set_field("password"), on_submit=add_user, width=fw,
                               password=True, icon=ft.Icons.LOCK_OUTLINE),
            ]),
            ft.Row([th.primary_button("Tambah Pengguna", add_user)]),
        ]),
    )

    # -- dialog -----------------------------------------------------------------
    def confirm(title, body, label, color, on_yes):
        def run(e=None):
            page.pop_dialog()
            on_yes()
        page.show_dialog(ft.AlertDialog(
            modal=True, title=th.txt(title, 18, th.POPPINS_BOLD),
            content=th.txt(body, 13, th.POPPINS, th.GRAY_600, height=1.5),
            actions=[
                ft.TextButton(content=th.txt("Batal", 14, th.POPPINS_SEMI, th.GRAY_600),
                              on_click=lambda ev: page.pop_dialog()),
                ft.TextButton(content=th.txt(label, 14, th.POPPINS_BOLD, color), on_click=run),
            ],
        ))

    def ask_reset(target):
        def do():
            try:
                temp = users.reset_password(user, target)
            except ValidationError as exc:
                toast(str(exc))
                return
            page.show_dialog(ft.AlertDialog(
                modal=True, title=th.txt("Password sementara dibuat", 18, th.POPPINS_BOLD),
                content=ft.Column(tight=True, spacing=12, width=360, controls=[
                    th.txt(f"Password baru untuk {target.username} (hanya ditampilkan sekali):",
                           13, th.POPPINS, th.GRAY_600, height=1.5),
                    ft.Container(
                        padding=ft.Padding.symmetric(horizontal=16, vertical=12), border_radius=10,
                        bgcolor=th.PAGE_BG, border=ft.Border.all(1, th.CARD_BORDER),
                        content=ft.Text(temp, selectable=True, size=20, weight=ft.FontWeight.BOLD,
                                        color=th.TEXT_PRIMARY, font_family="monospace")),
                    th.txt("Sampaikan ke pengguna secara langsung dan minta ia segera menyimpannya. "
                           "Password lama sudah tidak berlaku.", 12, th.POPPINS, th.GRAY_500, height=1.5),
                ]),
                actions=[ft.TextButton(content=th.txt("Selesai", 14, th.POPPINS_BOLD, th.PRIMARY),
                                       on_click=lambda ev: page.pop_dialog())],
            ))

        def handler(e=None):
            confirm("Reset password?",
                    f"Password lama {target.username} akan diganti password sementara baru.",
                    "Ya, Reset", th.PRIMARY, do)
        return handler

    def toggle_active(target):
        def apply(active):
            try:
                users.set_active(user, target, active)
            except ValidationError as exc:
                toast(str(exc))
                return
            toast(f"Akun {target.username} {'diaktifkan' if active else 'dinonaktifkan'}.")
            go("pengguna")

        def handler(e=None):
            if target.active:
                confirm("Nonaktifkan akun?",
                        f"{target.full_name} ({target.username}) tidak akan bisa login. "
                        "Riwayat reservasinya tetap tersimpan dan akun dapat diaktifkan lagi.",
                        "Ya, Nonaktifkan", th.DANGER, lambda: apply(False))
            else:
                apply(True)
        return handler

    rows = [_row(u, u is user or u.id == user.id, content_w, ask_reset(u), toggle_active(u))
            for u in all_users]
    list_card = ft.Container(
        width=content_w, bgcolor=th.WHITE, border=ft.Border.all(1, th.CARD_BORDER), border_radius=16,
        padding=20, shadow=th.SHADOW_CARD,
        content=ft.Column(spacing=0, controls=[
            th.txt("Daftar Pengguna", 16, th.POPPINS_BOLD, th.TEXT_PRIMARY),
            ft.Divider(color=th.CARD_BORDER, height=33),
            ft.Column(spacing=8, controls=rows),
        ]),
    )

    body = ft.Container(
        width=content_w, margin=ft.Margin.only(left=margin, right=margin),
        content=ft.Column(spacing=20, controls=[summary, add_card, list_card]),
    )
    return ft.Container(
        padding=ft.Padding.only(top=48, bottom=80),
        content=ft.Column(spacing=32, controls=[
            ft.Row([th.hero("Kelola Pengguna",
                             "Tambah akun, atur role, dan kelola akses pengguna SIRIUS",
                             width, margin)]),
            ft.Row([body], alignment=ft.MainAxisAlignment.CENTER),
        ]),
    )


def _row(target, is_self, content_w, on_reset, on_toggle):
    wide = content_w >= 860
    color = ROLE_COLOR.get(target.role.key, th.PRIMARY)
    identity = ft.Row(spacing=14, expand=True, vertical_alignment=ft.CrossAxisAlignment.CENTER, controls=[
        ft.Container(width=42, height=42, border_radius=21, bgcolor=th.tint(color),
                     alignment=ft.Alignment.CENTER, content=th.txt(target.initial, 16, th.POPPINS_BOLD, color)),
        ft.Column(spacing=2, tight=True, controls=[
            th.txt(target.full_name + ("  (Anda)" if is_self else ""), 14, th.POPPINS_SEMI, th.TEXT_PRIMARY),
            th.txt(f"@{target.username}", 12, th.POPPINS, th.GRAY_500),
        ]),
    ])
    badges = ft.Row(tight=True, spacing=8, controls=[
        th.badge(target.role.label, color),
        th.badge("Aktif", SUCCESS) if target.active else th.badge("Nonaktif", "#667085"),
    ])
    if is_self:
        actions = ft.Container(padding=ft.Padding.symmetric(horizontal=8, vertical=12),
                               content=th.txt("Tidak ada aksi untuk akun sendiri", 12, th.POPPINS, th.GRAY_500))
    else:
        actions = ft.Row(tight=True, spacing=10, controls=[
            th.secondary_button("Reset Password", on_reset, height=40),
            th.secondary_button("Nonaktifkan" if target.active else "Aktifkan", on_toggle, height=40,
                                color=th.DANGER if target.active else SUCCESS),
        ])
    inner = (
        ft.Row(spacing=16, vertical_alignment=ft.CrossAxisAlignment.CENTER, controls=[identity, badges, actions])
        if wide else ft.Column(spacing=12, controls=[identity, badges, actions])
    )
    return ft.Container(padding=16, border_radius=12, bgcolor=th.PAGE_BG if not target.active else th.WHITE,
                        border=ft.Border.all(1, th.CARD_BORDER), content=inner)
