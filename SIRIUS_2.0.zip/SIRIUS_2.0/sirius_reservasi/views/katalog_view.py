from __future__ import annotations

import flet as ft

from patterns.strategy import ALL_STRATEGIES
from views import theme as th

AMENITY_ICONS = {
    "desktop_windows": ft.Icons.DESKTOP_WINDOWS,
    "volume_up": ft.Icons.VOLUME_UP,
}


def build(width: float, repo, app_state, go, toast):
    margin = 68 if width >= 800 else 16
    content_w = width - 2 * margin
    two_col_card = content_w >= 760  # image panel beside content panel

    # -- Strategy pattern in action: a row of chips lets the user swap the
    # active RoomSortStrategy. The view only ever calls strategy.apply(...).
    current_cls = type(app_state.sort_strategy)
    chips = ft.Row(
        spacing=8,
        wrap=True,
        controls=[
            ft.Container(
                padding=ft.Padding.symmetric(horizontal=14, vertical=8),
                border_radius=20,
                bgcolor=th.PRIMARY if cls is current_cls else th.WHITE,
                border=ft.Border.all(1, th.PRIMARY if cls is current_cls else th.CARD_BORDER),
                ink=True,
                on_click=lambda e, c=cls: _set_strategy(app_state, c, go),
                content=th.txt(
                    cls.label, 13, th.POPPINS_SEMI,
                    th.WHITE if cls is current_cls else th.PRIMARY,
                ),
            )
            for cls in ALL_STRATEGIES
        ],
    )

    rooms = app_state.sort_strategy.apply(list(repo.rooms))
    cards = [_room_card(r, two_col_card, go, toast) for r in rooms]

    body = ft.Container(
        width=content_w,
        margin=ft.Margin.only(left=margin, right=margin),
        content=ft.Column(spacing=24, controls=[chips, ft.Column(spacing=24, controls=cards)]),
    )

    return ft.Container(
        padding=ft.Padding.only(top=48, bottom=80),
        content=ft.Column(
            spacing=32,
            controls=[
                ft.Row([th.hero(
                    "Katalog Ruangan",
                    "Pilih ruangan yang sesuai dengan kebutuhan kegiatan Anda",
                    width, margin,
                )]),
                ft.Row([body], alignment=ft.MainAxisAlignment.CENTER),
            ],
        ),
    )


def _set_strategy(app_state, cls, go):
    app_state.sort_strategy = cls()
    go("katalog")


def _room_card(room, two_col, go, toast):
    status_label = "Tersedia" if room.available else "Jadwal Penuh"
    status_color = "#027A48" if room.available else "#B42318"

    image_panel = ft.Container(
        bgcolor=room.color,
        border_radius=12,
        width=240 if two_col else None,
        height=180,
        alignment=ft.Alignment.CENTER,
        content=ft.Icon(ft.Icons.MEETING_ROOM, color=th.WHITE, size=56),
    )

    amenity_rows = ft.Column(
        spacing=10,
        controls=[
            ft.Row(
                spacing=12,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
                controls=[
                    ft.Container(
                        width=36, height=36, border_radius=8, bgcolor=th.PAGE_BG,
                        alignment=ft.Alignment.CENTER,
                        content=ft.Icon(AMENITY_ICONS.get(a.icon, ft.Icons.CIRCLE), size=18, color=th.PRIMARY),
                    ),
                    ft.Column(spacing=0, tight=True, controls=[
                        th.txt(a.title, 13, th.POPPINS_SEMI, th.TEXT_PRIMARY),
                        th.txt(a.subtitle, 12, th.POPPINS, th.GRAY_500),
                    ]),
                ],
            )
            for a in room.amenities
        ],
    )

    def book(e=None, room_id=room.id):
        go("pengajuan", room_id=room_id)

    content_panel = ft.Column(
        spacing=14,
        expand=True,
        controls=[
            ft.Row(
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                controls=[
                    th.txt(room.name, 20, th.POPPINS_BOLD, th.TEXT_PRIMARY),
                    th.badge(status_label, status_color),
                ],
            ),
            th.txt("Fasilitas Tersedia", 13, th.POPPINS_SEMI, th.GRAY_600),
            amenity_rows,
            th.txt(f"Kapasitas : {room.capacity} Orang", 13, th.POPPINS, th.GRAY_600),
            th.txt(f"Durasi Maksimum : {room.duration_max_hours} Jam", 13, th.POPPINS, th.GRAY_600),
            ft.Container(expand=True),
            th.primary_button("Buat Pengajuan", book, height=48),
        ],
    )

    inner = (
        ft.Row(spacing=24, vertical_alignment=ft.CrossAxisAlignment.START,
               controls=[image_panel, content_panel])
        if two_col
        else ft.Column(spacing=16, controls=[image_panel, content_panel])
    )

    return ft.Container(
        bgcolor=th.WHITE,
        border=ft.Border.all(1, th.CARD_BORDER),
        border_radius=16,
        padding=24,
        shadow=th.SHADOW_CARD,
        content=inner,
    )
