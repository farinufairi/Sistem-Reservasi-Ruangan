"""Design tokens read from the Figma file (HV9jRnOoxTZT8FKY2G054m) plus the
small widget helpers every view reuses, so visual tweaks happen in one
place instead of being copy-pasted across views."""
from __future__ import annotations

import flet as ft

PAGE_BG = "#F8F8FF"
CARD_BORDER = "#E6E6FA"
PRIMARY = "#030095"
LOGIN_TEXT = "#1E1E77"
TEXT_PRIMARY = "#101828"
GRAY_400 = "#98A2B3"
GRAY_500 = "#667085"
GRAY_600 = "#475467"
HERO_TITLE = "#111827"
HERO_SUB = "#6B7280"
WHITE = "#FFFFFF"
NAV_FALLBACK = "#3F3D8F"

NAVBAR_IMG = "https://www.figma.com/api/mcp/asset/e50dea23-b221-49ef-820f-e082ea55b7aa.png"
LOGO_IMG = "https://www.figma.com/api/mcp/asset/497cf05d-2f3b-4fb4-a3c7-cc505d782903.png"

POPPINS = "Poppins"
POPPINS_SEMI = "Poppins SemiBold"
POPPINS_BOLD = "Poppins Bold"
JAKARTA_MED = "Jakarta Medium"
JAKARTA_BOLD = "Jakarta Bold"
JAKARTA_XBOLD = "Jakarta ExtraBold"
LOGO_FONT = "Pochaevsk"  # not bundled (not on Google Fonts) -> serif fallback

FONT_MAP = {
    POPPINS: "fonts/Poppins-Regular.ttf",
    POPPINS_SEMI: "fonts/Poppins-SemiBold.ttf",
    POPPINS_BOLD: "fonts/Poppins-Bold.ttf",
    JAKARTA_MED: "fonts/PlusJakartaSans-Medium.ttf",
    JAKARTA_BOLD: "fonts/PlusJakartaSans-Bold.ttf",
    JAKARTA_XBOLD: "fonts/PlusJakartaSans-ExtraBold.ttf",
}

SHADOW_CARD = [
    ft.BoxShadow(blur_radius=14, offset=ft.Offset(0, 12), color="#12101828"),
    ft.BoxShadow(blur_radius=1, offset=ft.Offset(0, 1), color="#0D101828"),
]
SHADOW_INPUT = ft.BoxShadow(blur_radius=2, offset=ft.Offset(0, 1), color="#0D101828")
SHADOW_PRIMARY_BTN = ft.BoxShadow(blur_radius=9, offset=ft.Offset(0, 8), color="#26030095")

DANGER = "#B42318"

DAYS = ["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"]
MONTHS = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli",
          "Agustus", "September", "Oktober", "November", "Desember"]


def tint(color: str, alpha: str = "1A") -> str:
    """Warna transparan dari warna #RRGGBB. Flet membaca hex 8 digit sebagai
    #AARRGGBB (alpha di DEPAN), jadi alpha tidak boleh ditempel di belakang.
    1A = ~10%, 26 = ~15%."""
    return f"#{alpha}{color.lstrip('#')[-6:]}"


def fmt_date(d) -> str:
    return f"{DAYS[d.weekday()]}, {d.day} {MONTHS[d.month - 1]} {d.year}"


def fmt_time(t) -> str:
    return f"{t.hour:02d}:{t.minute:02d} WIB"


def fmt_relative(moment) -> str:
    import datetime as dt
    delta = dt.datetime.now() - moment
    secs = delta.total_seconds()
    if secs < 60:
        return "Baru saja"
    if secs < 3600:
        return f"{int(secs // 60)} menit lalu"
    if secs < 86400:
        return f"{int(secs // 3600)} jam lalu"
    return f"{int(secs // 86400)} hari lalu"


def txt(value, size, family=POPPINS, color=TEXT_PRIMARY, height=None, spacing=None, **kw):
    return ft.Text(
        value,
        size=size,
        color=color,
        font_family=family,
        style=ft.TextStyle(height=height, letter_spacing=spacing),
        **kw,
    )


def badge(label: str, color: str, bg: str | None = None):
    return ft.Container(
        bgcolor=bg or tint(color),  # ~10% tint of the status color
        border_radius=20,
        padding=ft.Padding.symmetric(horizontal=12, vertical=6),
        content=txt(label, 12, POPPINS_SEMI, color),
    )


def section_header(number, title):
    return ft.Row(
        spacing=10,
        vertical_alignment=ft.CrossAxisAlignment.CENTER,
        controls=[
            ft.Container(
                width=28,
                height=28,
                bgcolor=PAGE_BG,
                border=ft.Border.all(1, CARD_BORDER),
                border_radius=8,
                alignment=ft.Alignment.CENTER,
                content=txt(str(number), 12, POPPINS_BOLD, PRIMARY),
            ),
            txt(title, 16, POPPINS_BOLD, TEXT_PRIMARY, height=24 / 16),
        ],
    )


def hero(title: str, subtitle: str, width: float, left: float):
    h1 = 56 if width >= 900 else (40 if width >= 600 else 32)
    sub = 18 if width >= 600 else 16
    hero_w = max(200, min(760, width - left - 16))
    return ft.Container(
        width=hero_w,
        margin=ft.Margin.only(left=left),
        content=ft.Column(
            spacing=16,
            controls=[
                txt(title, h1, JAKARTA_XBOLD, HERO_TITLE, height=1.1),
                txt(subtitle, sub, JAKARTA_MED, HERO_SUB, height=1.5),
            ],
        ),
    )


def primary_button(label: str, on_click, height=44, expand=False):
    return ft.Container(
        height=height,
        expand=expand,
        bgcolor=PRIMARY,
        border_radius=10,
        padding=ft.Padding.symmetric(horizontal=24),
        alignment=ft.Alignment.CENTER,
        shadow=SHADOW_PRIMARY_BTN,
        ink=True,
        on_click=on_click,
        content=txt(label, 14, POPPINS_BOLD, WHITE),
    )


def secondary_button(label: str, on_click, height=44, expand=False, color=PRIMARY):
    return ft.Container(
        height=height,
        expand=expand,
        bgcolor=WHITE,
        border=ft.Border.all(1, color),
        border_radius=10,
        padding=ft.Padding.symmetric(horizontal=20),
        alignment=ft.Alignment.CENTER,
        ink=True,
        on_click=on_click,
        content=txt(label, 14, POPPINS_SEMI, color),
    )


def filled_button(label: str, on_click, color=PRIMARY, height=44, expand=False):
    """Seperti primary_button tetapi warnanya bisa diganti (mis. hijau untuk Setujui)."""
    return ft.Container(
        height=height, expand=expand, bgcolor=color, border_radius=10,
        padding=ft.Padding.symmetric(horizontal=24), alignment=ft.Alignment.CENTER,
        shadow=ft.BoxShadow(blur_radius=9, offset=ft.Offset(0, 8), color=tint(color, "26")),
        ink=True, on_click=on_click, content=txt(label, 14, POPPINS_BOLD, WHITE),
    )


def summary_card(icon, color, count, label, caption, content_w, per_row=3):
    w = max(220, content_w / per_row - 12) if content_w >= 700 else content_w
    icon_box = ft.Container(width=44, height=44, border_radius=22, bgcolor=tint(color),
                            alignment=ft.Alignment.CENTER, content=ft.Icon(icon, color=color, size=22))
    number = txt(str(count), 26, POPPINS_BOLD, TEXT_PRIMARY)
    name = txt(label, 13, POPPINS, GRAY_500)
    if w < 380:
        # Kartu sempit: keterangan ditaruh DI BAWAH label (boleh turun baris),
        # bukan di sisi kanan yang akan terpotong.
        content = ft.Row(vertical_alignment=ft.CrossAxisAlignment.CENTER, spacing=16, controls=[
            icon_box,
            ft.Column(expand=True, spacing=0, controls=[
                number, name, ft.Container(height=2), txt(caption, 12, POPPINS, GRAY_500)]),
        ])
    else:
        content = ft.Row(vertical_alignment=ft.CrossAxisAlignment.CENTER, spacing=16, controls=[
            icon_box,
            ft.Column(spacing=0, tight=True, controls=[number, name]),
            # expand + text_align: keterangan mengisi sisa ruang dan turun baris bila perlu
            ft.Container(expand=True, alignment=ft.Alignment.CENTER_RIGHT,
                         content=txt(caption, 12, POPPINS, GRAY_500, text_align=ft.TextAlign.RIGHT)),
        ])
    return ft.Container(
        width=w, bgcolor=WHITE, border=ft.Border.all(1, CARD_BORDER), border_radius=16,
        padding=20, shadow=SHADOW_CARD, content=content,
    )


def input_field(label, *, value="", hint="", on_change=None, on_submit=None, width=None,
                password=False, icon=None, autofocus=False):
    """Field teks bergaya sama dengan form Pengajuan (label di atas, tinggi 44)."""
    tf = ft.TextField(
        value=value, hint_text=hint, on_change=on_change, on_submit=on_submit,
        password=password, can_reveal_password=password, autofocus=autofocus,
        prefix_icon=icon, height=44, border=ft.InputBorder.OUTLINE, border_radius=8,
        border_color=GRAY_400, border_width=1, focused_border_color=PRIMARY, filled=True,
        bgcolor=WHITE, content_padding=ft.Padding.symmetric(horizontal=12),
        text_vertical_align=ft.VerticalAlignment.CENTER,
        text_style=ft.TextStyle(font_family=POPPINS, size=14, letter_spacing=0.25, color=TEXT_PRIMARY),
        hint_style=ft.TextStyle(font_family=POPPINS, size=14, color=GRAY_400),
    )
    return ft.Column(width=width, spacing=4, controls=[
        txt(label, 12, POPPINS, GRAY_600, height=16 / 12, spacing=-0.2),
        ft.Container(border_radius=8, shadow=SHADOW_INPUT, content=tf),
    ])


_NOTICE = {
    "danger": (DANGER, "#FEF3F2", "#FECDCA", ft.Icons.EVENT_BUSY),
    "warning": ("#B54708", "#FFFAEB", "#FEDF89", ft.Icons.WARNING_AMBER_ROUNDED),
}


def notice(message: str, kind: str = "warning"):
    """Kotak peringatan satu baris/paragraf (merah = menghalangi, kuning = informasi)."""
    color, bg, border, icon = _NOTICE[kind]
    return ft.Container(
        padding=ft.Padding.symmetric(horizontal=14, vertical=12), bgcolor=bg,
        border=ft.Border.all(1, border), border_radius=10,
        content=ft.Row(spacing=10, vertical_alignment=ft.CrossAxisAlignment.START, controls=[
            ft.Icon(icon, size=18, color=color),
            ft.Container(expand=True, content=txt(message, 13, POPPINS, color, height=1.5)),
        ]),
    )
