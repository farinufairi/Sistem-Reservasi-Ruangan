from __future__ import annotations

import flet as ft

from services.reservation_service import ValidationError
from views import theme as th

SUCCESS = "#027A48"

# (label chip, status_label di Reservation; None = semua)
FILTERS = [
    ("Menunggu", "Pending"),
    ("Disetujui", "Approved"),
    ("Ditolak", "Rejected"),
    ("Dibatalkan", "Dibatalkan"),
    ("Semua", None),
]


def build(width: float, page: ft.Page, repo, service, app_state, go, toast, user):
    margin = 68 if width >= 800 else 16
    content_w = width - 2 * margin
    everything = repo.reservations_visible_to(user)
    count = lambda label: sum(1 for r in everything if r.status_label == label)  # noqa: E731

    summary = ft.Row(wrap=True, spacing=16, run_spacing=16, controls=[
        th.summary_card(ft.Icons.HOURGLASS_EMPTY, "#B54708", count("Pending"), "Menunggu",
                        "Perlu keputusan", content_w, per_row=4),
        th.summary_card(ft.Icons.CHECK_CIRCLE, SUCCESS, count("Approved"), "Disetujui",
                        "Reservasi aktif", content_w, per_row=4),
        th.summary_card(ft.Icons.CANCEL, th.DANGER, count("Rejected"), "Ditolak",
                        "Tidak disetujui", content_w, per_row=4),
        th.summary_card(ft.Icons.EVENT_BUSY, "#667085", count("Dibatalkan"), "Dibatalkan",
                        "Oleh pemohon", content_w, per_row=4),
    ])

    # -- filter ----------------------------------------------------------------
    active = app_state.approval_filter

    def set_filter(value):
        def handler(e=None):
            app_state.approval_filter = value
            go("persetujuan")
        return handler

    chips = ft.Row(spacing=8, wrap=True, controls=[
        ft.Container(
            padding=ft.Padding.symmetric(horizontal=14, vertical=8), border_radius=20,
            bgcolor=th.PRIMARY if status == active else th.WHITE,
            border=ft.Border.all(1, th.PRIMARY if status == active else th.CARD_BORDER),
            ink=True, on_click=set_filter(status),
            content=th.txt(
                f"{label} ({count(status)})" if status else f"{label} ({len(everything)})",
                13, th.POPPINS_SEMI, th.WHITE if status == active else th.PRIMARY),
        )
        for label, status in FILTERS
    ])

    shown = [r for r in everything if active is None or r.status_label == active]
    # yang menunggu: paling lama dulu (antrian); lainnya: terbaru dulu
    if active == "Pending":
        shown.sort(key=lambda r: r.created_at)

    # -- aksi ----------------------------------------------------------------
    def approve(reservation):
        def handler(e=None):
            try:
                service.approve(reservation, user)
            except ValidationError as exc:
                toast(str(exc))
                return
            toast(f"Pengajuan {reservation.id} disetujui.")
            go("persetujuan")
        return handler

    def reject(reservation):
        def do_reject(e=None):
            page.pop_dialog()
            try:
                service.reject(reservation, user)
            except ValidationError as exc:
                toast(str(exc))
                return
            toast(f"Pengajuan {reservation.id} ditolak.")
            go("persetujuan")

        def ask(e=None):
            page.show_dialog(ft.AlertDialog(
                modal=True,
                title=th.txt("Tolak pengajuan ini?", 18, th.POPPINS_BOLD),
                content=th.txt(
                    f"{reservation.room.name} • {reservation.schedule_text()}\n"
                    f"Pemohon: {reservation.requester}\n\n"
                    "Keputusan ini tidak dapat diubah setelah disimpan.",
                    13, th.POPPINS, th.GRAY_600, height=1.5),
                actions=[
                    ft.TextButton(content=th.txt("Batal", 14, th.POPPINS_SEMI, th.GRAY_600),
                                  on_click=lambda ev: page.pop_dialog()),
                    ft.TextButton(content=th.txt("Ya, Tolak", 14, th.POPPINS_BOLD, th.DANGER),
                                  on_click=do_reject),
                ],
            ))
        return ask

    def conflicts_of(r):
        if r.status_label != "Pending":
            return [], []
        hard = service.find_conflicts(r.room, r.date, r.time, r.duration_hours, exclude=r)
        soft = [x for x in service.find_conflicts(r.room, r.date, r.time, r.duration_hours,
                                                  exclude=r, include_pending=True) if x not in hard]
        return hard, soft

    if shown:
        cards = [_card(r, content_w, approve(r), reject(r), *conflicts_of(r)) for r in shown]
    else:
        empty = "Tidak ada pengajuan yang menunggu keputusan." if active == "Pending" \
            else "Belum ada pengajuan pada kategori ini."
        cards = [ft.Container(
            bgcolor=th.WHITE, border=ft.Border.all(1, th.CARD_BORDER), border_radius=16,
            padding=32, alignment=ft.Alignment.CENTER,
            content=th.txt(empty, 14, th.POPPINS, th.GRAY_500),
        )]

    body = ft.Container(
        width=content_w, margin=ft.Margin.only(left=margin, right=margin),
        content=ft.Column(spacing=20, controls=[summary, chips, ft.Column(spacing=20, controls=cards)]),
    )

    return ft.Container(
        padding=ft.Padding.only(top=48, bottom=80),
        content=ft.Column(spacing=32, controls=[
            ft.Row([th.hero("Persetujuan Pengajuan",
                             "Tinjau dan putuskan pengajuan ruangan dari para pemohon",
                             width, margin)]),
            ft.Row([body], alignment=ft.MainAxisAlignment.CENTER),
        ]),
    )


def _detail(label, value):
    return ft.Column(spacing=4, controls=[
        th.txt(label, 12, th.POPPINS, th.GRAY_500),
        th.txt(value, 14, th.POPPINS_SEMI, th.TEXT_PRIMARY),
    ])


def _card(reservation, content_w, on_approve, on_reject, hard=(), soft=()):
    wide = content_w >= 900
    details = ft.Row(wrap=True, spacing=24, run_spacing=16, controls=[
        _detail("Pemohon", reservation.requester or "-"),
        _detail("Jadwal", reservation.schedule_text()),
        _detail("Durasi", f"{reservation.duration_hours} Jam"),
        _detail("Tujuan", reservation.purpose),
    ])
    header = ft.Row(controls=[
        th.badge(reservation.status_label, reservation.status_color),
        ft.Container(width=12),
        th.txt(f"ID reservasi • {reservation.id}", 13, th.POPPINS, th.GRAY_500),
    ])
    warnings = []
    if hard:
        warnings.append(th.notice(
            f"Bentrok dengan reservasi yang sudah disetujui ({hard[0].id}, {hard[0].slot_text()}). "
            "Pengajuan ini tidak dapat disetujui; tolak atau minta pemohon memilih jadwal lain.", "danger"))
    elif soft:
        ids = ", ".join(x.id for x in soft)
        warnings.append(th.notice(
            f"Waktu sama dengan pengajuan lain yang masih menunggu ({ids}). "
            "Setelah salah satu disetujui, yang lain tidak dapat disetujui.", "warning"))

    left = ft.Column(spacing=16, expand=True, controls=[
        header, th.txt(reservation.room.name, 22, th.POPPINS_BOLD, th.TEXT_PRIMARY), details,
        th.txt(f"Diajukan {th.fmt_relative(reservation.created_at)}", 12, th.POPPINS, th.GRAY_500),
        *warnings,
    ])

    if reservation.status_label == "Pending":
        # Pengajuan yang bentrok dengan reservasi Approved tidak diberi tombol Setujui.
        action = ft.Row(tight=True, spacing=12, controls=[
            th.secondary_button("Tolak", on_reject, height=48, color=th.DANGER),
            *([] if hard else [th.filled_button("Setujui", on_approve, color=SUCCESS, height=48)]),
        ])
    else:
        who = f"oleh {reservation.reviewed_by}" if reservation.reviewed_by else ""
        note = {"Approved": "Disetujui", "Rejected": "Ditolak"}.get(reservation.status_label)
        action = ft.Container(
            padding=ft.Padding.symmetric(horizontal=16, vertical=12),
            content=th.txt(f"{note} {who}".strip() if note else "Dibatalkan oleh pemohon",
                           13, th.POPPINS, th.GRAY_500),
        )

    inner = (
        ft.Row(alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
               vertical_alignment=ft.CrossAxisAlignment.CENTER, controls=[left, action])
        if wide else ft.Column(spacing=16, controls=[left, action])
    )
    return ft.Container(
        bgcolor=th.WHITE, border=ft.Border.all(1, th.CARD_BORDER), border_radius=16,
        padding=28, shadow=th.SHADOW_CARD, content=inner,
    )
