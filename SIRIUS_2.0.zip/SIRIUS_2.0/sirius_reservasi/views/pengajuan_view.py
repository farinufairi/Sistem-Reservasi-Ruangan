from __future__ import annotations

import datetime as dt

import flet as ft

from services.reservation_service import ValidationError
from views import theme as th


def build(width: float, page: ft.Page, repo, service, app_state, go, toast, file_picker, user):
    margin = 40 if width >= 800 else 16
    card_w = min(1241, width - 2 * margin)
    card_pad = 32 if width >= 600 else 20
    inner = card_w - 2 * card_pad - 2
    two_col = inner >= 640
    fw = (inner - 16) / 2 if two_col else inner

    draft = app_state.form_draft
    if app_state.consume_preselect_room():
        room = repo.room_by_id(app_state.selected_room_id)
        if room:
            draft["room_id"] = room.id

    def selected_room():
        return repo.room_by_id(draft.get("room_id"))

    def choose_room(room_id):
        def handler(e=None):
            draft["room_id"] = room_id
            go("pengajuan")
        return handler

    def open_date(e=None):
        today = dt.date.today()

        def on_change(ev):
            v = ev.control.value
            draft["date"] = v.date() if isinstance(v, dt.datetime) else v
            go("pengajuan")

        page.show_dialog(ft.DatePicker(
            value=draft.get("date"),
            first_date=dt.datetime(today.year, today.month, today.day),
            last_date=dt.datetime(today.year + 1, 12, 31),
            on_change=on_change,
        ))

    def open_time(e=None):
        def on_change(ev):
            draft["time"] = ev.control.value
            go("pengajuan")

        page.show_dialog(ft.TimePicker(value=draft.get("time") or dt.time(8, 0), on_change=on_change))

    def on_purpose(e):
        draft["purpose"] = e.control.value

    async def pick_files(e=None):
        picked = await file_picker.pick_files(allow_multiple=True)
        if picked:
            draft.setdefault("files", []).extend(f.name for f in picked)
            go("pengajuan")

    def remove_file(name):
        def handler(e=None):
            draft["files"].remove(name)
            go("pengajuan")
        return handler

    def save_draft(e=None):
        toast("Draft tersimpan. Anda bisa melanjutkan pengisian kapan saja selama sesi ini.")

    def submit(e=None):
        try:
            reservation = service.submit(
                user, selected_room(), draft.get("purpose", ""), draft.get("date"), draft.get("time"),
            )
        except ValidationError as exc:
            toast(str(exc))
            return
        app_state.form_draft = {"files": []}
        toast(f"Pengajuan {reservation.id} terkirim, menunggu persetujuan.")
        go("riwayat")

    def select_box(icon, value, placeholder, box_width, on_click=None):
        shown = value if value else placeholder
        return ft.Container(
            width=box_width, height=44, bgcolor=th.WHITE,
            border=ft.Border.all(1, th.GRAY_400), border_radius=8, padding=12,
            shadow=th.SHADOW_INPUT, on_click=on_click,
            content=ft.Row(
                spacing=10, vertical_alignment=ft.CrossAxisAlignment.CENTER,
                controls=[
                    ft.Icon(icon, size=20, color=th.PRIMARY),
                    ft.Text(shown, size=14, color=th.TEXT_PRIMARY, expand=True, max_lines=1,
                            overflow=ft.TextOverflow.ELLIPSIS,
                            style=ft.TextStyle(letter_spacing=0.25)),
                    ft.Icon(ft.Icons.KEYBOARD_ARROW_DOWN, size=20, color=th.PRIMARY),
                ],
            ),
        )

    def field(label, control, field_width):
        return ft.Column(
            width=field_width, spacing=4, horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
            controls=[th.txt(label, 12, th.POPPINS, th.GRAY_600, height=16 / 12, spacing=-0.2), control],
        )

    room = selected_room()
    room_box = select_box(ft.Icons.MEETING_ROOM, room.name if room else None, "Pilih Ruangan", fw)
    room_field = field("Ruangan", ft.PopupMenuButton(
        width=fw, content=room_box,
        items=[ft.PopupMenuItem(content=th.txt(r.name, 14), on_click=choose_room(r.id)) for r in repo.rooms],
    ), fw)
    date_field = field("Jadwal", select_box(
        ft.Icons.CALENDAR_MONTH,
        th.fmt_date(draft["date"]) if draft.get("date") else None,
        "Pilih Hari/Tanggal", fw, on_click=open_date,
    ), fw)

    purpose = ft.TextField(
        value=draft.get("purpose", ""), hint_text="Tujuan pengajuan", on_change=on_purpose,
        height=44, border=ft.InputBorder.OUTLINE, border_radius=8, border_color=th.GRAY_400,
        border_width=1, focused_border_color=th.PRIMARY, filled=True, bgcolor=th.WHITE,
        content_padding=ft.Padding.symmetric(horizontal=12),
        text_vertical_align=ft.VerticalAlignment.CENTER,
        text_style=ft.TextStyle(font_family=th.POPPINS, size=14, letter_spacing=0.25, color=th.TEXT_PRIMARY),
        hint_style=ft.TextStyle(font_family=th.POPPINS, size=14, color=th.GRAY_400),
    )
    purpose_field = field("Tujuan", ft.Container(width=fw, border_radius=8, shadow=th.SHADOW_INPUT,
                                                  content=purpose), fw)
    time_field = field("Jam", select_box(
        ft.Icons.ACCESS_TIME_FILLED,
        th.fmt_time(draft["time"]) if draft.get("time") else None,
        "Pilih Jam", fw, on_click=open_time,
    ), fw)

    upload_btn = ft.Container(
        height=48, bgcolor=th.WHITE, border=ft.Border.all(1, "#33030095"), border_radius=10,
        padding=ft.Padding.symmetric(horizontal=16), ink=True, on_click=pick_files,
        content=ft.Row(tight=True, spacing=12, vertical_alignment=ft.CrossAxisAlignment.CENTER,
                        controls=[ft.Icon(ft.Icons.UPLOAD_SHARP, size=24, color=th.PRIMARY),
                                  th.txt("Add File", 14, th.POPPINS_SEMI, th.PRIMARY, height=20 / 14)]),
    )
    file_chips = [
        ft.Container(
            bgcolor=th.WHITE, border=ft.Border.all(1, th.CARD_BORDER), border_radius=8,
            padding=ft.Padding.only(left=10, top=4, bottom=4, right=4),
            content=ft.Row(tight=True, spacing=4, controls=[
                th.txt(n, 12, th.POPPINS, th.GRAY_600),
                ft.IconButton(ft.Icons.CLOSE, icon_size=14, icon_color=th.GRAY_500, on_click=remove_file(n)),
            ]),
        )
        for n in draft.get("files", [])
    ]
    upload_area = ft.Column(spacing=12, controls=[
        ft.Row(tight=True, spacing=8, vertical_alignment=ft.CrossAxisAlignment.CENTER, controls=[
            th.txt("Dokumen Tambahan", 12, th.POPPINS, th.GRAY_600, height=16 / 12, spacing=-0.2),
            th.badge("Opsional", th.GRAY_500, "#F2F4F7"),
        ]),
        ft.Row([upload_btn]),
        th.txt("Tidak wajib diisi. Lampirkan surat tugas, proposal, atau dokumen pendukung lain bila ada.",
               12, th.POPPINS, th.GRAY_500, height=18 / 12),
        *([ft.Row(file_chips, wrap=True, spacing=8, run_spacing=8)] if file_chips else []),
    ])

    # -- cek bentrok langsung saat ruangan, tanggal, dan jam sudah dipilih ----
    availability = []
    if room and draft.get("date") and draft.get("time"):
        hard = service.find_conflicts(room, draft["date"], draft["time"])
        soft = [r for r in service.find_conflicts(room, draft["date"], draft["time"], include_pending=True)
                if r not in hard]
        if hard:
            availability.append(th.notice(
                f"Jadwal bentrok: {room.name} sudah dipesan pada {hard[0].slot_text()}. "
                "Pilih jam atau ruangan lain agar pengajuan dapat dikirim.", "danger"))
        elif soft:
            availability.append(th.notice(
                "Sudah ada pengajuan lain pada waktu ini yang masih menunggu persetujuan. "
                "Pengajuan Anda tetap dapat dikirim, tetapi hanya salah satu yang bisa disetujui.", "warning"))

    wide_footer = inner >= 640
    note = th.txt(
        "Pastikan data sudah benar sebelum dikirim. Dokumen tambahan bersifat opsional. "
        "Simpan sebagai draft bila ingin melanjutkan nanti.",
        12, th.POPPINS, th.GRAY_500, height=18 / 12,
    )
    if wide_footer:
        # NOTE: no Row(wrap=True) inside a Row here -- Wrap gets unbounded width and
        # Flutter renders a grey error box instead of the buttons.
        footer_row = ft.Row(
            spacing=24, vertical_alignment=ft.CrossAxisAlignment.CENTER,
            controls=[
                ft.Container(expand=True, content=note),
                ft.Row(tight=True, spacing=12, controls=[
                    th.secondary_button("Simpan Draft", save_draft),
                    th.primary_button("Ajukan", submit),
                ]),
            ],
        )
    else:
        footer_row = ft.Column(spacing=16, controls=[
            note,
            ft.Row(spacing=12, controls=[
                th.secondary_button("Simpan Draft", save_draft, expand=True),
                th.primary_button("Ajukan", submit, expand=True),
            ]),
        ])
    footer = ft.Column(spacing=20, controls=[ft.Divider(height=1, color=th.CARD_BORDER), footer_row])

    card = ft.Container(
        width=card_w, bgcolor=th.WHITE, border=ft.Border.all(1, th.CARD_BORDER), border_radius=16,
        padding=card_pad, shadow=th.SHADOW_CARD,
        content=ft.Column(spacing=24, controls=[
            ft.Column(spacing=6, controls=[
                th.txt("Form Pengajuan Ruangan", 24 if width >= 600 else 20, th.POPPINS_BOLD,
                       th.TEXT_PRIMARY, height=32 / 24),
                th.txt("Isi data pengajuan dengan lengkap untuk memudahkan proses verifikasi dan "
                       "penjadwalan.", 14, th.POPPINS, th.GRAY_500, height=22 / 14),
            ]),
            ft.Column(spacing=16, controls=[th.section_header(1, "Detail Ruangan"),
                                             ft.Row(spacing=16, run_spacing=16, wrap=True,
                                                    controls=[room_field, date_field])]),
            ft.Column(spacing=16, controls=[th.section_header(2, "Detail Kegiatan"),
                                             ft.Row(spacing=16, run_spacing=16, wrap=True,
                                                    controls=[purpose_field, time_field])]),
            ft.Column(spacing=16, controls=[th.section_header(3, "Dokumen Tambahan"), upload_area]),
            *availability,
            footer,
        ]),
    )

    top_gap = 103 if width >= 800 else 48
    gap_to_card = 74 if width >= 800 else 32
    return ft.Container(
        padding=ft.Padding.only(top=top_gap, bottom=80),
        content=ft.Column(spacing=gap_to_card, controls=[
            ft.Row([th.hero("Form Pengajuan", "Isi form berikut untuk melakukan pengajuan ruangan",
                             width, max(16, (width - card_w) / 2 - 16))]),
            ft.Row([card], alignment=ft.MainAxisAlignment.CENTER),
        ]),
    )
