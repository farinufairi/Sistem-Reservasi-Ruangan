from __future__ import annotations

import flet as ft

from views import theme as th

ICONS = {
    "hourglass_empty": ft.Icons.HOURGLASS_EMPTY,
    "check_circle": ft.Icons.CHECK_CIRCLE,
    "cancel": ft.Icons.CANCEL,
    "event_busy": ft.Icons.EVENT_BUSY,
    "inbox": ft.Icons.INBOX,
}


def build(width: float, repo, go, toast, user):
    margin = 68 if width >= 800 else 16
    content_w = width - 2 * margin
    notifications = repo.notifications_for(user)
    own = repo.reservations_visible_to(user)

    approved = sum(1 for r in own if r.status_label == "Approved")
    rejected = sum(1 for r in own if r.status_label == "Rejected")
    cancelled = sum(1 for r in own if r.status_label == "Dibatalkan")

    summary = ft.Row(
        wrap=True, spacing=16, run_spacing=16,
        controls=[
            th.summary_card(ft.Icons.CHECK_CIRCLE, "#027A48", approved, "Disetujui",
                           "Reservasi aktif", content_w),
            th.summary_card(ft.Icons.CANCEL, "#B42318", rejected, "Ditolak",
                           "Perlu ruangan lain", content_w),
            th.summary_card(ft.Icons.EVENT_BUSY, "#667085", cancelled, "Dibatalkan",
                           "Oleh pemohon", content_w),
        ],
    )

    def mark_read(n):
        def handler(e=None):
            n.read = True
            go("notifikasi")
        return handler

    if not notifications:
        rows = [ft.Container(
            bgcolor=th.WHITE, border=ft.Border.all(1, th.CARD_BORDER), border_radius=16,
            padding=32, alignment=ft.Alignment.CENTER,
            content=th.txt("Belum ada notifikasi.", 14, th.POPPINS, th.GRAY_500),
        )]
    else:
        rows = [_notification_row(n, mark_read(n)) for n in notifications]

    list_card = ft.Container(
        bgcolor=th.WHITE, border=ft.Border.all(1, th.CARD_BORDER), border_radius=16,
        padding=20, shadow=th.SHADOW_CARD,
        content=ft.Column(spacing=0, controls=[
            ft.Row(alignment=ft.MainAxisAlignment.SPACE_BETWEEN, controls=[
                th.txt("Semua Notifikasi", 16, th.POPPINS_BOLD, th.TEXT_PRIMARY),
                ft.Row(spacing=6, controls=[
                    ft.Container(width=8, height=8, border_radius=4, bgcolor=th.PRIMARY),
                    th.txt(f"{repo.unread_notification_count(user)} belum dibaca", 13, th.POPPINS, th.GRAY_500),
                ]),
            ]),
            ft.Divider(color=th.CARD_BORDER, height=33),
            ft.Column(spacing=14, controls=rows),
        ]),
    )

    body = ft.Container(
        width=content_w, margin=ft.Margin.only(left=margin, right=margin),
        content=ft.Column(spacing=20, controls=[summary, list_card]),
    )

    return ft.Container(
        padding=ft.Padding.only(top=48, bottom=80),
        content=ft.Column(spacing=32, controls=[
            ft.Row([th.hero("Notifikasi Reservasi",
                             "Pantau perkembangan pengajuan ruangan dan perubahan terbaru",
                             width, margin)]),
            ft.Row([body], alignment=ft.MainAxisAlignment.CENTER),
        ]),
    )


def _notification_row(n, on_click):
    icon = ICONS.get(n.icon, ft.Icons.NOTIFICATIONS)
    return ft.Container(
        padding=16, border_radius=12, bgcolor=th.PAGE_BG if not n.read else th.WHITE,
        ink=True, on_click=on_click,
        content=ft.Row(spacing=16, vertical_alignment=ft.CrossAxisAlignment.START, controls=[
            ft.Container(width=42, height=42, border_radius=21, bgcolor=th.tint(n.color),
                         alignment=ft.Alignment.CENTER, content=ft.Icon(icon, color=n.color, size=20)),
            ft.Column(expand=True, spacing=6, controls=[
                ft.Row(alignment=ft.MainAxisAlignment.SPACE_BETWEEN, controls=[
                    ft.Row(spacing=8, controls=[
                        th.txt(n.title, 14, th.POPPINS_SEMI, th.TEXT_PRIMARY),
                        *([ft.Container(width=8, height=8, border_radius=4, bgcolor=th.PRIMARY)]
                          if not n.read else []),
                    ]),
                    th.txt(th.fmt_relative(n.created_at), 12, th.POPPINS, th.GRAY_500),
                ]),
                th.txt(n.message, 13, th.POPPINS, th.GRAY_600, height=1.4),
            ]),
        ]),
    )
