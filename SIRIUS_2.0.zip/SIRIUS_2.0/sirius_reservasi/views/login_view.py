from __future__ import annotations

import flet as ft

from services.auth_service import AuthenticationError
from views import theme as th


def build(width: float, auth, app_state, go):
    card_w = min(480, width - 32)
    card_pad = 32 if width >= 600 else 20
    inner = card_w - 2 * card_pad - 2
    form = app_state.login_form   # isi field bertahan walau halaman di-render ulang

    def on_username(e):
        form["username"] = e.control.value

    def on_password(e):
        form["password"] = e.control.value

    def submit(e=None):
        try:
            user = auth.login(form.get("username", ""), form.get("password", ""))
        except AuthenticationError as exc:
            form["error"] = str(exc)
            form["password"] = ""          # jangan menyimpan password yang salah
            go("login")
            return
        app_state.reset_session()
        go(user.role.home_route)

    error = form.get("error")
    error_box = ft.Container(
        visible=bool(error), padding=ft.Padding.symmetric(horizontal=12, vertical=10),
        bgcolor="#FEF3F2", border=ft.Border.all(1, "#FECDCA"), border_radius=8,
        content=ft.Row(spacing=8, vertical_alignment=ft.CrossAxisAlignment.CENTER, controls=[
            ft.Icon(ft.Icons.ERROR_OUTLINE, size=18, color=th.DANGER),
            ft.Container(expand=True, content=th.txt(error or "", 13, th.POPPINS, th.DANGER)),
        ]),
    )

    card = ft.Container(
        width=card_w, bgcolor=th.WHITE, border=ft.Border.all(1, th.CARD_BORDER), border_radius=16,
        padding=card_pad, shadow=th.SHADOW_CARD,
        content=ft.Column(spacing=20, controls=[
            ft.Column(spacing=6, controls=[
                th.txt("Masuk ke Akun Anda", 24 if width >= 600 else 20, th.POPPINS_BOLD,
                       th.TEXT_PRIMARY, height=32 / 24),
                th.txt("Gunakan username dan password yang terdaftar untuk melanjutkan.",
                       14, th.POPPINS, th.GRAY_500, height=22 / 14),
            ]),
            error_box,
            th.input_field("Username", value=form.get("username", ""), hint="Masukkan username",
                           on_change=on_username, on_submit=submit, width=inner,
                           icon=ft.Icons.PERSON_OUTLINE, autofocus=True),
            th.input_field("Password", value=form.get("password", ""), hint="Masukkan password",
                           on_change=on_password, on_submit=submit, width=inner, password=True,
                           icon=ft.Icons.LOCK_OUTLINE),
            th.primary_button("Masuk", submit, height=48, expand=True),
        ]),
    )

    top_gap = 103 if width >= 800 else 48
    gap_to_card = 56 if width >= 800 else 32
    return ft.Container(
        padding=ft.Padding.only(top=top_gap, bottom=80),
        content=ft.Column(spacing=gap_to_card, controls=[
            ft.Row([th.hero("Masuk", "Masuk untuk mengajukan atau menyetujui reservasi ruangan",
                             width, max(16, (width - card_w) / 2 - 16))]),
            ft.Row([card], alignment=ft.MainAxisAlignment.CENTER),
        ]),
    )
