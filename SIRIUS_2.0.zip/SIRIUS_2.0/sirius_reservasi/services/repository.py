from __future__ import annotations

import os
import threading

from models.notification import Notification
from models.reservation import Reservation
from models.room import Amenity, Room
from models.user import User
from patterns.factory import ADMIN_AUDIENCE
from patterns.role import AdminRole, Permission, PemohonRole
from patterns.singleton import SingletonMeta


def _seed_rooms() -> list[Room]:
    smart_monitor = Amenity("desktop_windows", "Smart Monitor", "4K Resolution")
    sound_system = Amenity("volume_up", "Sound System", "Speaker Standar")
    return [
        Room("sidang", "Ruang Sidang", 10, 2, [smart_monitor, sound_system], available=False,
             color="#030095"),
        Room("rapat-a", "Ruang Rapat A", 10, 2, [smart_monitor, sound_system], available=False,
             color="#5B21B6"),
        Room("seminar", "Ruang Seminar", 60, 2, [smart_monitor, sound_system], available=True,
             color="#027A48"),
        Room("lab", "Lab Komputer", 30, 3, [smart_monitor, sound_system], available=True,
             color="#B54708"),
        Room("aula", "Aula Utama", 150, 4, [smart_monitor, sound_system], available=True,
             color="#B42318"),
    ]


def _seed_users() -> list[User]:
    """Akun demo. Password dapat diganti lewat environment variable agar tidak
    perlu mengubah kode: SIRIUS_FARIZI_PASSWORD dan SIRIUS_ADMIN_PASSWORD."""
    return [
        User.create("Farizi", "Farizi", PemohonRole(),
                    os.environ.get("SIRIUS_FARIZI_PASSWORD", "farizi123")),
        User.create("admin", "Admin SIRIUS", AdminRole(),
                    os.environ.get("SIRIUS_ADMIN_PASSWORD", "admin123")),
    ]


class Repository(metaclass=SingletonMeta):
    """Single source of truth for the whole app. Because `SingletonMeta`
    guarantees one instance per process, every view that calls
    `Repository()` gets back the exact same rooms/reservations/
    notifications lists — no prop-drilling or duplicated state needed."""

    def __init__(self) -> None:
        self.rooms: list[Room] = _seed_rooms()
        self.users: list[User] = _seed_users()
        self.reservations: list[Reservation] = []
        self.notifications: list[Notification] = []
        self._next_seq = 1
        # Pengecekan bentrok + penyimpanan harus atomik: repository dipakai bersama
        # oleh semua sesi browser, jadi dua admin/pemohon tidak boleh lolos bersamaan.
        self.lock = threading.RLock()

    def room_by_id(self, room_id: str) -> Room | None:
        return next((r for r in self.rooms if r.id == room_id), None)

    def user_by_username(self, username: str) -> User | None:
        key = (username or "").strip().lower()
        return next((u for u in self.users if u.username.lower() == key), None)

    def next_reservation_id(self, on_date) -> str:
        code = f"RS-{on_date:%Y-%m-%d}-{self._next_seq:02d}"
        self._next_seq += 1
        return code

    def reservations_sorted(self) -> list[Reservation]:
        return sorted(self.reservations, key=lambda r: r.created_at, reverse=True)

    # -- query yang dibatasi sesuai siapa yang login --------------------
    def reservations_visible_to(self, user: User) -> list[Reservation]:
        """Pemohon hanya melihat miliknya sendiri; admin melihat semuanya."""
        items = self.reservations_sorted()
        if user.can(Permission.APPROVE_RESERVATION):
            return items
        return [r for r in items if r.requester == user.username]

    def _audience(self, user: User) -> str:
        return ADMIN_AUDIENCE if user.can(Permission.APPROVE_RESERVATION) else user.username

    def notifications_for(self, user: User) -> list[Notification]:
        audience = self._audience(user)
        return sorted((n for n in self.notifications if n.recipient == audience),
                      key=lambda n: n.created_at, reverse=True)

    def unread_notification_count(self, user: User) -> int:
        return sum(1 for n in self.notifications_for(user) if not n.read)
