from __future__ import annotations

import datetime as dt

from models.reservation import Reservation, slot_bounds
from models.room import Room
from models.user import User
from patterns.observer import (
    EVENT_APPROVED,
    EVENT_CANCELLED,
    EVENT_REJECTED,
    EVENT_SUBMITTED,
    ReservationSubject,
)
from patterns.role import Permission
from patterns.state import InvalidTransition
from services.repository import Repository


class ValidationError(Exception):
    """Raised when submitted form data fails a business rule."""


class ConflictError(ValidationError):
    """Raised when the requested room/time overlaps an approved reservation.
    Subclass of ValidationError so views show it as a normal toast."""


class AuthorizationError(ValidationError):
    """Raised when the acting user's role does not allow the action.
    Subclass of ValidationError so existing `except ValidationError`
    handlers in the views show it as a normal toast."""


def require_permission(actor: User | None, permission: str, message: str) -> User:
    # Dicek di service (bukan hanya menyembunyikan tombol di UI), supaya aturan
    # akses tetap berlaku walau view dipanggil dengan cara lain. Akun yang sudah
    # dinonaktifkan juga ditolak walau objek User-nya masih dipegang sesi lama.
    if actor is None or not actor.active or not actor.can(permission):
        raise AuthorizationError(message)
    return actor


_require = require_permission


class ReservationService(ReservationSubject):
    """All reservation business logic lives here — never in a Flet
    on_click handler. This is also the Observer *subject*: every state
    change is broadcast via `self.notify(...)` to whoever subscribed
    (see patterns/observer.py)."""

    def __init__(self, repo: Repository) -> None:
        super().__init__()
        self.repo = repo

    # -- bentrok jadwal ---------------------------------------------------
    def find_conflicts(
        self,
        room: Room | None,
        date: dt.date | None,
        time: dt.time | None,
        duration_hours: int | None = None,
        exclude: Reservation | None = None,
        include_pending: bool = False,
    ) -> list[Reservation]:
        """Reservasi lain yang beririsan dengan slot ini. Secara default hanya
        yang Approved (mengunci slot); `include_pending=True` menambahkan yang
        masih menunggu, untuk peringatan saja."""
        if room is None or date is None or time is None:
            return []
        start, end = slot_bounds(date, time, duration_hours or room.duration_max_hours)
        return [
            r for r in self.repo.reservations
            if r is not exclude
            and (r.holds_slot or (include_pending and r.status_label == "Pending"))
            and r.overlaps(room.id, start, end)
        ]

    # -- create ---------------------------------------------------------
    def submit(
        self,
        actor: User | None,
        room: Room | None,
        purpose: str,
        date: dt.date | None,
        time: dt.time | None,
        duration_hours: int | None = None,
        _allow_past_date: bool = False,
    ) -> Reservation:
        _require(actor, Permission.SUBMIT_RESERVATION,
                 "Hanya pemohon yang dapat mengajukan ruangan.")
        missing = []
        if room is None:
            missing.append("Ruangan")
        if not (purpose or "").strip():
            missing.append("Tujuan")
        if date is None:
            missing.append("Jadwal")
        if time is None:
            missing.append("Jam")
        if missing:
            raise ValidationError("Lengkapi dulu: " + ", ".join(missing))

        if date < dt.date.today() and not _allow_past_date:
            raise ValidationError("Jadwal tidak boleh di tanggal yang sudah lewat.")

        hours = duration_hours or room.duration_max_hours
        with self.repo.lock:   # cek bentrok + simpan harus satu langkah atomik
            clash = self.find_conflicts(room, date, time, hours)
            if clash:
                raise ConflictError(
                    f"{room.name} sudah dipesan pada {clash[0].slot_text()}. "
                    "Pilih jam atau ruangan lain.")
            reservation = Reservation(
                id=self.repo.next_reservation_id(date),
                room=room,
                purpose=purpose.strip(),
                date=date,
                time=time,
                duration_hours=hours,
                requester=actor.username,
            )
            self.repo.reservations.append(reservation)
        self.notify(reservation, EVENT_SUBMITTED)
        return reservation

    # -- transitions ------------------------------------------------------
    def approve(self, reservation: Reservation, actor: User | None) -> None:
        self._review(reservation, actor, "approve", EVENT_APPROVED)

    def reject(self, reservation: Reservation, actor: User | None) -> None:
        self._review(reservation, actor, "reject", EVENT_REJECTED)

    def _review(self, reservation: Reservation, actor: User | None, action: str, event: str) -> None:
        admin = _require(actor, Permission.APPROVE_RESERVATION,
                         "Hanya admin yang dapat menyetujui atau menolak pengajuan.")
        with self.repo.lock:
            if action == "approve" and reservation.status_label == "Pending":
                # Cek ulang saat menyetujui: pengajuan lain di slot yang sama
                # mungkin sudah disetujui lebih dulu.
                clash = self.find_conflicts(reservation.room, reservation.date, reservation.time,
                                            reservation.duration_hours, exclude=reservation)
                if clash:
                    raise ConflictError(
                        f"Tidak dapat disetujui: bentrok dengan reservasi {clash[0].id} "
                        f"({clash[0].slot_text()}). Tolak pengajuan ini atau minta pemohon memilih jadwal lain.")
            try:
                getattr(reservation, action)()
            except InvalidTransition as exc:
                raise ValidationError(str(exc)) from exc
            reservation.reviewed_by = admin.username
            reservation.reviewed_at = dt.datetime.now()
        self.notify(reservation, event)

    def cancel(self, reservation: Reservation, actor: User | None) -> None:
        user = _require(actor, Permission.CANCEL_OWN_RESERVATION,
                        "Anda tidak memiliki akses untuk membatalkan reservasi.")
        if reservation.requester != user.username:
            raise AuthorizationError("Anda hanya dapat membatalkan reservasi milik sendiri.")
        try:
            reservation.cancel()
        except InvalidTransition as exc:
            raise ValidationError(str(exc)) from exc
        self.notify(reservation, EVENT_CANCELLED)
