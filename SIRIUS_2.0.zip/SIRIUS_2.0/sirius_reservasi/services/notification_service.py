from __future__ import annotations

from typing import TYPE_CHECKING

from patterns.factory import NotificationFactory
from patterns.observer import ReservationObserver
from services.repository import Repository

if TYPE_CHECKING:
    from models.reservation import Reservation


class NotificationService(ReservationObserver):
    """Concrete Observer: whenever ReservationService.notify(...) fires,
    this turns the event into a Notification (via NotificationFactory) and
    stores it in the shared Repository, where the Notifikasi view reads it
    from."""

    def __init__(self, repo: Repository) -> None:
        self.repo = repo

    def update(self, reservation: "Reservation", event: str) -> None:
        self.repo.notifications.extend(NotificationFactory.create_all(event, reservation))
