"""Populates demo reservations by calling the real ReservationService, so
the seed data exercises the same State/Observer/Factory path a real user
action would (submit -> Pending -> approve/reject) instead of being
inserted directly into the repository."""
from __future__ import annotations

import datetime as dt

from services.reservation_service import ReservationService
from services.repository import Repository


def seed_demo_data(service: ReservationService, repo: Repository) -> None:
    today = dt.date.today()
    pemohon = repo.user_by_username("Farizi")
    admin = repo.user_by_username("admin")
    # _allow_past_date=True is used only here: it lets the demo seed a few
    # already-concluded reservations (for Riwayat to show something besides
    # an empty list) without weakening the real "no past dates" rule that
    # applies to actual user submissions.

    r1 = service.submit(pemohon, repo.room_by_id("sidang"), "Sidang Tugas Akhir",
                         today - dt.timedelta(days=12), dt.time(10, 0), 2, _allow_past_date=True)
    service.approve(r1, admin)

    r2 = service.submit(pemohon, repo.room_by_id("sidang"), "Sidang Tugas Akhir",
                         today - dt.timedelta(days=10), dt.time(10, 0), 2, _allow_past_date=True)
    service.approve(r2, admin)

    r3 = service.submit(pemohon, repo.room_by_id("lab"), "Praktikum Basis Data",
                         today - dt.timedelta(days=8), dt.time(10, 0), 2, _allow_past_date=True)
    service.reject(r3, admin)

    service.submit(pemohon, repo.room_by_id("aula"), "Seminar Nasional",
                    today + dt.timedelta(days=2), dt.time(13, 0), 3)
    # left Pending on purpose, to show the "Ajukan Pembatalan" action
