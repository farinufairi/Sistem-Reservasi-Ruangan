from __future__ import annotations

import re
import secrets
import string

from models.user import User, hash_password
from patterns.role import ROLES, Permission
from services.repository import Repository
from services.reservation_service import ValidationError, require_permission

USERNAME_RE = re.compile(r"^[A-Za-z0-9_.-]{3,30}$")
MIN_PASSWORD = 8
# tanpa karakter yang mudah tertukar (0/O, 1/l/I) agar password sementara mudah diketik
_TEMP_ALPHABET = "".join(c for c in string.ascii_letters + string.digits if c not in "0O1lI")


def validate_password(password: str) -> None:
    if len(password or "") < MIN_PASSWORD:
        raise ValidationError(f"Password minimal {MIN_PASSWORD} karakter.")
    if not (any(c.isalpha() for c in password) and any(c.isdigit() for c in password)):
        raise ValidationError("Password harus mengandung huruf dan angka.")


def generate_temp_password(length: int = 10) -> str:
    while True:
        pw = "".join(secrets.choice(_TEMP_ALPHABET) for _ in range(length))
        if any(c.isalpha() for c in pw) and any(c.isdigit() for c in pw):
            return pw


class UserService:
    """Semua aturan manajemen akun. Hanya role dengan permission MANAGE_USERS
    (Admin) yang boleh memanggilnya — dicek di sini, bukan hanya di UI."""

    def __init__(self, repo: Repository) -> None:
        self.repo = repo

    def _admin(self, actor: User | None) -> User:
        return require_permission(actor, Permission.MANAGE_USERS,
                                  "Hanya admin yang dapat mengelola pengguna.")

    # -- create -----------------------------------------------------------
    def create_user(self, actor: User | None, username: str, full_name: str,
                    role_key: str, password: str) -> User:
        self._admin(actor)
        username = (username or "").strip()
        full_name = (full_name or "").strip()
        missing = [label for label, v in (("Username", username), ("Nama lengkap", full_name),
                                          ("Password", password)) if not v]
        if missing:
            raise ValidationError("Lengkapi dulu: " + ", ".join(missing))
        if not USERNAME_RE.match(username):
            raise ValidationError(
                "Username 3-30 karakter, hanya huruf, angka, titik, garis bawah, atau strip.")
        if role_key not in ROLES:
            raise ValidationError("Role tidak dikenal.")
        validate_password(password)
        if password.lower() == username.lower():
            raise ValidationError("Password tidak boleh sama dengan username.")

        with self.repo.lock:
            if self.repo.user_by_username(username):
                raise ValidationError(f"Username '{username}' sudah dipakai.")
            user = User.create(username, full_name, ROLES[role_key](), password)
            self.repo.users.append(user)
        return user

    # -- password ---------------------------------------------------------
    def reset_password(self, actor: User | None, target: User) -> str:
        """Membuat password sementara acak dan mengembalikannya (ditampilkan
        sekali ke admin). Password lama langsung tidak berlaku."""
        self._admin(actor)
        temp = generate_temp_password()
        target.salt, target.password_hash = hash_password(temp)
        return temp

    # -- aktif / nonaktif -----------------------------------------------------
    def set_active(self, actor: User | None, target: User, active: bool) -> None:
        admin = self._admin(actor)
        if not active:
            if target is admin or target.id == admin.id:
                raise ValidationError("Anda tidak dapat menonaktifkan akun sendiri.")
            with self.repo.lock:
                other_admins = [u for u in self.repo.users if u is not target and u.active
                                and u.can(Permission.MANAGE_USERS)]
                if target.can(Permission.MANAGE_USERS) and not other_admins:
                    raise ValidationError("Tidak dapat menonaktifkan admin terakhir.")
        target.active = active
