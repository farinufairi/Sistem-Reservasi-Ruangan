from __future__ import annotations

import time

from models.user import User
from patterns.role import Role
from services.repository import Repository

MAX_FAILED_ATTEMPTS = 5
LOCK_SECONDS = 30


class AuthenticationError(Exception):
    """Login gagal (pesan sengaja generik agar tidak membocorkan username)."""


class AuthService:
    """Satu instance per sesi browser: menyimpan siapa yang sedang login.
    Data user sendiri ada di Repository (Singleton) yang dipakai bersama."""

    def __init__(self, repo: Repository) -> None:
        self.repo = repo
        self._current: User | None = None
        self._failed: dict[str, list[float]] = {}   # username -> waktu gagal

    # -- login / logout ---------------------------------------------------
    def login(self, username: str, password: str) -> User:
        key = (username or "").strip().lower()
        if not key or not password:
            raise AuthenticationError("Username dan password wajib diisi.")

        remaining = self._lock_remaining(key)
        if remaining:
            raise AuthenticationError(
                f"Terlalu banyak percobaan gagal. Coba lagi dalam {remaining} detik.")

        user = self.repo.user_by_username(key)
        if user is None or not user.check_password(password):
            self._failed.setdefault(key, []).append(time.monotonic())
            raise AuthenticationError("Username atau password salah.")

        self._failed.pop(key, None)
        # Dicek SETELAH password benar, supaya status akun tidak bisa diintip
        # tanpa mengetahui password-nya.
        if not user.active:
            raise AuthenticationError("Akun Anda dinonaktifkan. Hubungi admin.")
        self._current = user
        return user

    def logout(self) -> None:
        self._current = None

    @property
    def current_user(self) -> User | None:
        # Admin menonaktifkan akun -> sesi yang sedang berjalan ikut berakhir.
        if self._current is not None and not self._current.active:
            self._current = None
        return self._current

    # -- akses ------------------------------------------------------------
    @property
    def role(self) -> Role | None:
        return self.current_user.role if self.current_user else None

    def can_access(self, route: str) -> bool:
        return bool(self.current_user and self.current_user.role.can_access(route))

    # -- internal -----------------------------------------------------------
    def _lock_remaining(self, key: str) -> int:
        now = time.monotonic()
        recent = [t for t in self._failed.get(key, []) if now - t < LOCK_SECONDS]
        self._failed[key] = recent
        if len(recent) >= MAX_FAILED_ATTEMPTS:
            return max(1, int(LOCK_SECONDS - (now - recent[0])))
        return 0
