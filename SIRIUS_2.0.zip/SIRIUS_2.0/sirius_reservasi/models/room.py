from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Amenity:
    icon: str
    title: str
    subtitle: str


@dataclass
class Room:
    id: str
    name: str
    capacity: int
    duration_max_hours: int
    amenities: list[Amenity] = field(default_factory=list)
    available: bool = True
    color: str = "#030095"  # tint used for the image-panel placeholder
