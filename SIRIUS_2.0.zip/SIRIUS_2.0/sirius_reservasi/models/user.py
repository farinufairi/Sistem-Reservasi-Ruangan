from __future__ import annotations

import hashlib
import hmac
import os
from dataclasses import dataclass

from patterns.role import Role

_ITERATIONS = 200_000


def hash_password(password: str, salt: bytes | None = None) -> tuple[bytes, bytes]:
    """PBKDF2-HMAC-SHA256 dengan salt acak per user. Password asli tidak
    pernah disimpan."""
    salt = salt or os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, _ITERATIONS)
    return salt, digest


@dataclass
class User:
    id: str
    username: str
    full_name: str
    role: Role
    salt: bytes
    password_hash: bytes
    active: bool = True   # akun nonaktif tidak bisa login; riwayatnya tetap disimpan

    @classmethod
    def create(cls, username: str, full_name: str, role: Role, password: str) -> "User":
        salt, digest = hash_password(password)
        return cls(id=f"U-{username.lower()}", username=username, full_name=full_name,
                   role=role, salt=salt, password_hash=digest)

    def check_password(self, password: str) -> bool:
        _, digest = hash_password(password, self.salt)
        return hmac.compare_digest(digest, self.password_hash)  # constant-time

    def can(self, permission: str) -> bool:
        return self.role.can(permission)

    @property
    def initial(self) -> str:
        return (self.full_name or self.username)[:1].upper()
