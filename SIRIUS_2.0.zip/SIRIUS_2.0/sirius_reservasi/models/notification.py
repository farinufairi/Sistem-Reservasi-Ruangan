from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field


@dataclass
class Notification:
    id: str
    icon: str
    color: str
    title: str
    message: str
    reservation_id: str
    recipient: str = ""   # username pemohon, atau "role:admin" untuk semua admin
    created_at: dt.datetime = field(default_factory=dt.datetime.now)
    read: bool = False
