from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field

from models.room import Room
from patterns.state import PendingState, ReservationState


def slot_bounds(date: dt.date, time: dt.time, hours: int) -> tuple[dt.datetime, dt.datetime]:
    start = dt.datetime.combine(date, time)
    return start, start + dt.timedelta(hours=hours)


def slot_text(date: dt.date, time: dt.time, hours: int) -> str:
    start, end = slot_bounds(date, time, hours)
    return f"{start:%d %b %Y}, {start:%H:%M}-{end:%H:%M} WIB"


@dataclass
class Reservation:
    """The State-pattern *context*: it never checks `if status == ...`
    itself, it just asks `self._state` what is allowed and lets the state
    object decide what the next state is."""

    id: str
    room: Room
    purpose: str
    date: dt.date
    time: dt.time
    duration_hours: int
    requester: str = ""                       # username pemohon
    reviewed_by: str | None = None            # username admin yang memutuskan
    reviewed_at: dt.datetime | None = None
    created_at: dt.datetime = field(default_factory=dt.datetime.now)
    _state: ReservationState = field(default_factory=PendingState)

    # -- read-only view of the current state -----------------------------
    @property
    def status_label(self) -> str:
        return self._state.label

    @property
    def status_color(self) -> str:
        return self._state.color

    @property
    def status_icon(self) -> str:
        return self._state.icon

    def can_cancel(self) -> bool:
        return self._state.can_cancel()

    @property
    def holds_slot(self) -> bool:
        return self._state.holds_slot

    # -- interval waktu -----------------------------------------------------
    @property
    def start(self) -> dt.datetime:
        return slot_bounds(self.date, self.time, self.duration_hours)[0]

    @property
    def end(self) -> dt.datetime:
        return slot_bounds(self.date, self.time, self.duration_hours)[1]

    def overlaps(self, room_id: str, start: dt.datetime, end: dt.datetime) -> bool:
        """Bentrok = ruangan sama dan interval beririsan. Jadwal yang saling
        menyambung (selesai 10:00, mulai 10:00) TIDAK dianggap bentrok."""
        return self.room.id == room_id and self.start < end and start < self.end

    def slot_text(self) -> str:
        return slot_text(self.date, self.time, self.duration_hours)

    # -- transitions (delegate to the state object) -----------------------
    def approve(self) -> None:
        self._state = self._state.approve()

    def reject(self) -> None:
        self._state = self._state.reject()

    def cancel(self) -> None:
        self._state = self._state.cancel()

    # -- display helpers ----------------------------------------------------
    @property
    def code(self) -> str:
        return self.id

    def schedule_text(self) -> str:
        return f"{self.date:%Y-%m-%d} Pukul {self.time:%H:%M} WIB"
